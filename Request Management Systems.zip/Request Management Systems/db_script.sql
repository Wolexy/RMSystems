/* This script create and prepare database for Request Management System (application). 
Prepared by Wole Ajala, CSUF AMSE program 2020
 */

CREATE DATABASE `amse_project` ;

use amse_project;

/* Create approval tables */
CREATE TABLE `approval` (
  `id` int NOT NULL AUTO_INCREMENT,
  `approval_id` varchar(6) NOT NULL DEFAULT 'AWT',
  `approval_description` varchar(45) DEFAULT 'Awaiting Decision',
  `rowid` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `approval_id_UNIQUE` (`approval_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/* create category table */
CREATE TABLE `category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_id` varchar(6) NOT NULL,
  `category_desc` varchar(45) DEFAULT NULL,
  `rowdate` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_id_UNIQUE` (`category_id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

/* create department table */
CREATE TABLE `department` (
  `id` int NOT NULL AUTO_INCREMENT,
  `department_id` varchar(5) NOT NULL,
  `department_name` varchar(45) DEFAULT NULL,
  `rowdate` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `department_id_UNIQUE` (`department_id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

/* create job table */
CREATE TABLE `job` (
  `id` int NOT NULL AUTO_INCREMENT,
  `job_id` varchar(4) NOT NULL,
  `job_desc` varchar(45) DEFAULT NULL,
  `department_id` varchar(45) DEFAULT NULL,
  `rowdate` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `job_id_UNIQUE` (`job_id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `department_id_idx` (`department_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/* create priority table */
CREATE TABLE `priority` (
  `id` int NOT NULL AUTO_INCREMENT,
  `priority_id` varchar(4) NOT NULL,
  `description` varchar(45) DEFAULT NULL,
  `rowdate` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `priority_id_UNIQUE` (`priority_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/* create request table */
CREATE TABLE `request` (
  `id` int NOT NULL AUTO_INCREMENT,
  `request_title` varchar(45) NOT NULL,
  `request_description` mediumtext,
  `request_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `department_id` varchar(10) DEFAULT NULL,
  `user_id` varchar(10) DEFAULT NULL,
  `job_id` varchar(10) DEFAULT NULL,
  `priority_id` varchar(10) DEFAULT NULL,
  `category_id` varchar(10) DEFAULT NULL,
  `subcategory_id` varchar(10) DEFAULT NULL,
  `site_id` varchar(10) DEFAULT NULL,
  `status_id` varchar(10) DEFAULT 'New',
  `technician_id` varchar(10) DEFAULT NULL,
  `email_to_notify` varchar(45) DEFAULT NULL,
  `approved_by` varchar(10) DEFAULT NULL,
  `isknown_issue` tinyint(1) NOT NULL DEFAULT '0',
  `related_case` varchar(45) DEFAULT NULL,
  `contact_number` varchar(45) DEFAULT NULL,
  `issue_date` datetime DEFAULT NULL,
  `approval_id` varchar(15) DEFAULT 'AWT',
  `rowdate` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/* create site table */
CREATE TABLE `site` (
  `id` int NOT NULL AUTO_INCREMENT,
  `site_id` varchar(6) NOT NULL,
  `site_desc` varchar(30) DEFAULT NULL,
  `location` varchar(20) DEFAULT NULL,
  `rowdate` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ID_UNIQUE` (`id`),
  UNIQUE KEY `site_id_UNIQUE` (`site_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/* create status table */
CREATE TABLE `status` (
  `id` int NOT NULL AUTO_INCREMENT,
  `status_id` varchar(15) NOT NULL,
  `status_description` varchar(45) DEFAULT NULL,
  `rowid` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `status_id_UNIQUE` (`status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/* create sub_category table */
CREATE TABLE `sub_category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `subcategory_id` varchar(6) NOT NULL,
  `category_id` varchar(6) DEFAULT NULL,
  `sub_category_desc` varchar(45) DEFAULT NULL,
  `rowdate` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `subcategory_id_UNIQUE` (`subcategory_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*create technician table */
CREATE TABLE `technician` (
  `id` int NOT NULL AUTO_INCREMENT,
  `technician_id` varchar(10) NOT NULL,
  `user_id` varchar(6) DEFAULT NULL,
  `user_name` varchar(45) DEFAULT NULL,
  `rowdate` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `department_id_UNIQUE` (`technician_id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/* create ticket table. This is not used for now*/
CREATE TABLE `ticket` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ticket_title` varchar(45) NOT NULL,
  `ticket_description` mediumtext,
  `ticket_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `user_id` varchar(10) DEFAULT NULL,
  `job_id` varchar(10) DEFAULT NULL,
  `priority_id` varchar(10) DEFAULT NULL,
  `category_id` varchar(10) DEFAULT NULL,
  `subcategory_id` varchar(10) DEFAULT NULL,
  `site_id` varchar(10) DEFAULT NULL,
  `status_id` varchar(10) DEFAULT 'New',
  `technician_id` varchar(10) DEFAULT NULL,
  `department_id` varchar(10) DEFAULT NULL,
  `approved_by` varchar(10) DEFAULT NULL,
  `known_issue` tinyint(1) DEFAULT NULL,
  `related_case` varchar(45) DEFAULT NULL,
  `rowdate` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/* create ticket_history table */
CREATE TABLE `ticket_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `history_id` varchar(45) NOT NULL,
  `ticket_id` int DEFAULT NULL,
  `creation_date` datetime DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  `completed_date` datetime DEFAULT NULL,
  `user_id` varchar(45) DEFAULT NULL,
  `technician_id` varchar(45) DEFAULT NULL,
  `rowdate` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `history_id_UNIQUE` (`history_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/* create user table */
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(6) NOT NULL,
  `username` varchar(45) DEFAULT NULL,
  `first_name` varchar(20) DEFAULT NULL,
  `last_name` varchar(20) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `department_id` varchar(45) DEFAULT NULL,
  `role_id` varchar(6) DEFAULT NULL,
  `site_id` varchar(6) DEFAULT NULL,
  `job_id` varchar(45) DEFAULT NULL,
  `rowdate` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `user_id_UNIQUE` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/* create user_role table */
CREATE TABLE `user_role` (
  `id` int NOT NULL AUTO_INCREMENT,
  `role_id` varchar(45) NOT NULL,
  `role_description` varchar(45) DEFAULT NULL,
  `rowid` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_id_UNIQUE` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/* create priority_count_view. This is used for dashboard report */
CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `amse`@`localhost` 
    SQL SECURITY DEFINER
VIEW `amse_project`.`priority_count_view` AS
    SELECT 
        `prior`.`description` AS `priority`,
        IFNULL(COUNT(`req`.`priority_id`), 0) AS `priority_count`
    FROM
        (`amse_project`.`priority` `prior`
        LEFT JOIN `amse_project`.`request` `req` ON ((`req`.`priority_id` = `prior`.`priority_id`)))
    GROUP BY `prior`.`description`
    ORDER BY `prior`.`priority_id`;
    
/* create request_view */
CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `amse`@`localhost` 
    SQL SECURITY DEFINER
VIEW `amse_project`.`request_view` AS
    SELECT 
        `req`.`id` AS `id`,
        `req`.`request_title` AS `title`,
        CONCAT(`amse_project`.`user`.`first_name`,
                ' ',
                `amse_project`.`user`.`last_name`) AS `requester`,
        `req`.`request_date` AS `request_date`,
        `tech`.`user_name` AS `technician`,
        `prior`.`description` AS `priority`,
        `appr`.`approval_description` AS `approval`,
        `stat`.`status_description` AS `status`
    FROM
        (((((`amse_project`.`request` `req`
        LEFT JOIN `amse_project`.`user` ON ((`req`.`user_id` = `amse_project`.`user`.`user_id`)))
        LEFT JOIN `amse_project`.`technician` `tech` ON ((`req`.`technician_id` = `tech`.`technician_id`)))
        LEFT JOIN `amse_project`.`priority` `prior` ON ((`req`.`priority_id` = `prior`.`priority_id`)))
        LEFT JOIN `amse_project`.`approval` `appr` ON ((`req`.`approval_id` = `appr`.`approval_id`)))
        LEFT JOIN `amse_project`.`status` `stat` ON ((`req`.`status_id` = `stat`.`status_id`)))
    ORDER BY `req`.`id`;
    
    /* create status_count_view. This report is used in dashboard report*/
    CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `amse`@`localhost` 
    SQL SECURITY DEFINER
VIEW `amse_project`.`status_count_view` AS
    SELECT 
        `stat`.`status_description` AS `status`,
        IFNULL(COUNT(`req`.`priority_id`), 0) AS `status_count`
    FROM
        (`amse_project`.`status` `stat`
        LEFT JOIN `amse_project`.`request` `req` ON ((`req`.`status_id` = `stat`.`status_id`)))
    GROUP BY `stat`.`status_description`
    ORDER BY `stat`.`status_id`;
    
    
/* insert data into tables */
/* department */
INSERT INTO amse_project.department( department_id,department_name)VALUES('MKT','Marketing');
INSERT INTO amse_project.department( department_id,department_name)VALUES('HRP','Human Resource & Personnel');
INSERT INTO amse_project.department( department_id,department_name)VALUES('ITT','Information Technology');
INSERT INTO amse_project.department( department_id,department_name)VALUES('FIN','Finance');
INSERT INTO amse_project.department( department_id,department_name)VALUES('SAL','Sales & Customer Relations');
INSERT INTO amse_project.department( department_id,department_name)VALUES('IMP','Import & Export');
INSERT INTO amse_project.department( department_id,department_name)VALUES('ADM','Administrative');

/*job */
INSERT INTO amse_project.job( job_id,job_desc, department_id)VALUES('J001','Marketing Manager', 'MKT');
INSERT INTO amse_project.job( job_id,job_desc, department_id)VALUES('J002','Assistant Marketing Manager', 'MKT');
INSERT INTO amse_project.job( job_id,job_desc, department_id)VALUES('J003','Marketing Officer I', 'MKT');
INSERT INTO amse_project.job( job_id,job_desc, department_id)VALUES('J004','Marketing Officer II', 'MKT');
INSERT INTO amse_project.job( job_id,job_desc, department_id)VALUES('J101','IT Manager', 'ITT');
INSERT INTO amse_project.job( job_id,job_desc, department_id)VALUES('J102','Software Engineer', 'ITT');
INSERT INTO amse_project.job( job_id,job_desc, department_id)VALUES('J103','System Analyst', 'ITT');
INSERT INTO amse_project.job( job_id,job_desc, department_id)VALUES('J104','Helpdesk support technician', 'ITT');
INSERT INTO amse_project.job( job_id,job_desc, department_id)VALUES('J201','Sales Manager', 'SAL');
INSERT INTO amse_project.job( job_id,job_desc, department_id)VALUES('J202','Sales Coordinator', 'SAL');
INSERT INTO amse_project.job( job_id,job_desc, department_id)VALUES('J301','Logistic Manager', 'IMP');
INSERT INTO amse_project.job( job_id,job_desc, department_id)VALUES('J401','HR Manager', 'HRP');
INSERT INTO amse_project.job( job_id,job_desc, department_id)VALUES('J402','HR Officer', 'HRP');
INSERT INTO amse_project.job( job_id,job_desc, department_id)VALUES('J501','Finance Manager', 'FIN');
INSERT INTO amse_project.job( job_id,job_desc, department_id)VALUES('J502','Senior Accountant', 'FIN');
INSERT INTO amse_project.job( job_id,job_desc, department_id)VALUES('J503','Account Officer', 'FIN');
INSERT INTO amse_project.job( job_id,job_desc, department_id)VALUES('J601','Admin Manager', 'ADM');
INSERT INTO amse_project.job( job_id,job_desc, department_id)VALUES('J602','Admin Officer', 'ADM');

/*priority */
INSERT INTO amse_project.priority( priority_id,description)VALUES('P001','Critical');
INSERT INTO amse_project.priority( priority_id,description)VALUES('P002','High');
INSERT INTO amse_project.priority( priority_id,description)VALUES('P003','Medium');
INSERT INTO amse_project.priority( priority_id,description)VALUES('P004','Low');

/*site */
INSERT INTO amse_project.site(Site_id,  site_desc, location)VALUES('SITE01','Head office', 'San Francisco');
INSERT INTO amse_project.site(Site_id, site_desc, location)VALUES('SITE02','East coast branch', 'Atlanta');
INSERT INTO amse_project.site(Site_id, site_desc, location)VALUES('SITE03','Midwest office', 'Chicago');
INSERT INTO amse_project.site(Site_id, site_desc, location)VALUES('SITE04','West Coast Satellite Office', 'Fullerton');

/* category */
INSERT INTO `amse_project`.`category`(`id`, `category_id`,`category_desc`,`rowdate`)
VALUES
('1', 'CAT001', 'Service Request', '2020-04-17 19:37:02'),
('2', 'CAT002', 'Incident', '2020-04-17 19:37:02'),
('3', 'CAT003', 'Information Request', '2020-04-17 19:39:56');

/* sub_category */
use amse_project ;
INSERT INTO amse_project.sub_category( subcategory_id,category_id, sub_category_desc)VALUES('SUB001','CAT001','Software Development');
INSERT INTO amse_project.sub_category( subcategory_id,category_id, sub_category_desc)VALUES('SUB002','CAT001','Software Maintenance');
INSERT INTO amse_project.sub_category( subcategory_id,category_id, sub_category_desc)VALUES('SUB003','CAT001','Hardware');
INSERT INTO amse_project.sub_category( subcategory_id,category_id, sub_category_desc)VALUES('SUB004','CAT001','Network');
INSERT INTO amse_project.sub_category( subcategory_id,category_id, sub_category_desc)VALUES('SUB005','CAT001','Other service request');
INSERT INTO amse_project.sub_category( subcategory_id,category_id, sub_category_desc)VALUES('SUB006','CAT002','Software failure');
INSERT INTO amse_project.sub_category( subcategory_id,category_id, sub_category_desc)VALUES('SUB007','CAT002','Hardware failure');
INSERT INTO amse_project.sub_category( subcategory_id,category_id, sub_category_desc)VALUES('SUB008','CAT002','Network failure');
INSERT INTO amse_project.sub_category( subcategory_id,category_id, sub_category_desc)VALUES('SUB009','CAT002','User account');
INSERT INTO amse_project.sub_category( subcategory_id,category_id, sub_category_desc)VALUES('SUB010','CAT002','Other incident');
INSERT INTO amse_project.sub_category( subcategory_id,category_id, sub_category_desc)VALUES('SUB011','CAT003','Information request');

/* user_role */
INSERT INTO amse_project.user_role(role_id, role_description)VALUES('U001','Admin User');
INSERT INTO amse_project.user_role(role_id, role_description)VALUES('U002','Regular User');
INSERT INTO amse_project.user_role(role_id, role_description)VALUES('U003','Guest');

/* technician */
INSERT INTO `amse_project`.`technician`(`id`,`technician_id`,`user_id`,`user_name`,`rowdate`)
VALUES
('1', 'TECH01', 'J101', 'Kola Ajala', '2020-04-18 00:43:57'),
('2', 'TECH02', 'J103', 'Brian Sang', '2020-04-18 00:43:57'),
('3', 'TECH03', 'J104', 'Brian Reju', '2020-04-18 00:43:57');

/* status */
INSERT INTO `amse_project`.`status`(`id`,`status_id`,`status_description`,`rowid`)
VALUES
('1', 'STS01', 'New', '2020-04-17 23:28:05'),
('2', 'STS02', 'In Progress', '2020-04-17 23:28:05'),
('3', 'STS03', 'On Hold', '2020-04-17 23:28:05'),
('4', 'STS04', 'Resolved', '2020-04-17 23:28:05'),
('5', 'STS05', 'Closed', '2020-04-17 23:28:05'),
('6', 'STS06', 'Canceled', '2020-04-17 23:28:05');

/* user */
INSERT INTO `amse_project`.`user`( `id`,`user_id`,`username`,`first_name`,`last_name`,`phone`,`email`,`password`,`department_id`,`role_id`,`site_id`,`job_id`,`rowdate`)
VALUES
( '1', 'MKT001', 'akuppari', 'Akhila', 'Kuppari', '0123456789', 'akuppari@amse.com', 'pa55w0rd', 'MKT', 'U002', 'SITE01', 'J001', '2020-04-17 00:00:00'),
('2', 'HRP001', 'apatole', 'Amisha', 'Patole', '0123456790', 'apatole@amse.com', 'pa55w0rd', 'HRP', 'U002', 'SITE02', 'J401', '2020-04-17 00:00:00'),
('3', 'ITT001', 'bmiguyen', 'Binh', 'Miguyen', '0123456791', 'bmiguyen@amse.com', 'pa55w0rd', 'ITT', 'U001', 'SITE03', 'J102', '2020-04-17 00:00:00'),
('4', 'ITT002', 'bsang', 'Brian', 'Sang', '0123456792', 'bsang@amse.com', 'pa55w0rd', 'ITT', 'U001', 'SITE04', 'J103', '2020-04-17 00:00:00'),
('5', 'FIN001', 'ckhen', 'Chuan', 'Khen', '0123456793', 'ckhen@amse.com', 'pa55w0rd', 'FIN', 'U002', 'SITE01', 'J501', '2020-04-17 00:00:00'),
('6', 'FIN002', 'dsamuel', 'David', 'Samuel', '0123456794', 'dsamuel@amse.com', 'pa55w0rd', 'FIN', 'U002', 'SITE02', 'J503', '2020-04-17 00:00:00'),
('7', 'SAL001', 'elaren', 'Erik', 'Laren', '0123456795', 'elaren@amse.com', 'pa55w0rd', 'SAL', 'U002', 'SITE03', 'J202', '2020-04-17 00:00:00'),
('8', 'MKT002', 'fsimon', 'Faheem', 'Simon', '0123456796', 'fsimon@amse.com', 'pa55w0rd', 'MKT', 'U002', 'SITE04', 'J001', '2020-04-17 00:00:00'),
('9', 'IMP001', 'hhazar', 'Hirad', 'Hazar', '0123456797', 'hhazar@amse.com', 'pa55w0rd', 'IMP', 'U002', 'SITE01', 'J302', '2020-04-17 00:00:00'),
('10', 'ADM001', 'jtantran', 'Jerome', 'Tantran', '0123456798', 'jtantran@amse.com', 'pa55w0rd', 'ADM', 'U002', 'SITE02', 'J601', '2020-04-17 00:00:00'),
('11', 'ADM002', 'jsong', 'Jong', 'Song', '0123456799', 'jsong@amse.com', 'pa55w0rd', 'ADM', 'U002', 'SITE03', 'J602', '2020-04-17 00:00:00'),
('12', 'HRP002', 'kkeneddy', 'Kaithe', 'Keneddy', '0123456800', 'kkeneddy@amse.com', 'pa55w0rd', 'HRP', 'U002', 'SITE04', 'J402', '2020-04-17 00:00:00'),
('13', 'SAL002', 'mfassin', 'Mallika', 'Fassin', '0123456801', 'mfassin@amse.com', 'pa55w0rd', 'SAL', 'U002', 'SITE01', 'J202', '2020-04-17 00:00:00'),
('14', 'FIN003', 'nbouyen', 'Ngan', 'Bouyen', '0123456802', 'nbouyen@amse.com', 'pa55w0rd', 'FIN', 'U002', 'SITE02', 'J502', '2020-04-17 00:00:00'),
('15', 'MKT003', 'pshnav', 'Priyanka', 'Shnav', '0123456803', 'pshnav@amse.com', 'pa55w0rd', 'MKT', 'U002', 'SITE03', 'J003', '2020-04-17 00:00:00'),
('16', 'SAL003', 'rvadrebati', 'Raghavendra', 'Vadrebati', '0123456804', 'rvadrebati@amse.com', 'pa55w0rd', 'SAL', 'U002', 'SITE04', 'J203', '2020-04-17 00:00:00'),
('17', 'ITT003', 'rdrogba', 'Reema', 'Drogba', '0123456805', 'rdrogba@amse.com', 'pa55w0rd', 'ITT', 'U001', 'SITE01', 'J103', '2020-04-17 00:00:00'),
('18', 'ITT004', 'sreju', 'Sai', 'Reju', '0123456806', 'sreju@amse.com', 'pa55w0rd', 'ITT', 'U001', 'SITE02', 'J104', '2020-04-17 00:00:00'),
('19', 'FIN004', 'squadri', 'Sapana', 'Quadri', '0123456807', 'squadri@amse.com', 'pa55w0rd', 'FIN', 'U002', 'SITE03', 'J503', '2020-04-17 00:00:00'),
('20', 'MKT004', 'ssauyer', 'Sayali', 'Sauyer', '0123456808', 'ssauyer@amse.com', 'pa55w0rd', 'MKT', 'U002', 'SITE04', 'J003', '2020-04-17 00:00:00'),
('21', 'IMP002', 'schan', 'Shaoshien', 'Chan', '0123456809', 'schan@amse.com', 'pa55w0rd', 'IMP', 'U002', 'SITE01', 'J301', '2020-04-17 00:00:00'),
('22', 'HRP003', 'vsuraju', 'Varun', 'Suraju', '0123456810', 'vsuraju@amse.com', 'pa55w0rd', 'HRP', 'U002', 'SITE02', 'J402', '2020-04-17 00:00:00'),
('23', 'ITT005', 'kajala', 'Kola', 'Ajala', '0123456811', 'kajala@amse.com', 'pa55w0rd', 'ITT', 'U001', 'SITE03', 'J101', '2020-04-17 00:00:00');

/*user_role */
INSERT INTO `amse_project`.`user_role`(`id`,`role_id`,`role_description`,`rowid`)
VALUES
('1', 'U001', 'Admin User', '2020-04-17 22:12:10'),
('2', 'U002', 'Regular User', '2020-04-17 22:12:11'),
('3', 'U003', 'Guest', '2020-04-17 22:12:11');

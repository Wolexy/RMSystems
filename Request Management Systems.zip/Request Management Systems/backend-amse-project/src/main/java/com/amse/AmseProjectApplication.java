package com.amse;
import com.amse.notify.SendMessage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class AmseProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(AmseProjectApplication.class, args);
        System.out.println("Hello there!");

       // SendMessage sendMessage = new SendMessage();
      // String msg =  sendMessage.sendSMS("Wole", 9096875549L);
      //  System.out.println(msg);
    }

}

package com.amse.service;

import com.amse.model.Approval;
import java.util.List;

public interface ApprovalServiceInterface {
    public List<Approval> findAll();

    public Approval findById(long theId);

    public void save(Approval theApproval);

    public void deleteById(Long theId);

}




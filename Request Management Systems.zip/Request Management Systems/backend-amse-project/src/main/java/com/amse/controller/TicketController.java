package com.amse.controller;

import com.amse.model.Ticket;
import com.amse.service.TicketService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:4200")
public class TicketController {

    private TicketService ticketService;

    @Autowired
    public TicketController(TicketService theTicketService) {
        ticketService = theTicketService;
    }

    // expose "/tickets" and return list of tickets
    @GetMapping("/tickets")
    public List<Ticket> findAll() {
        return ticketService.findAll();
    }

    // add mapping for GET /Tickets/{TicketId}

    @GetMapping("/tickets/{ticketId}")
    public Ticket getTicket(@PathVariable long ticketId) {

        Ticket theTicket = ticketService.findById(ticketId);

        if (theTicket == null) {
            throw new RuntimeException("Ticket id not found - " + ticketId);
        }

        return theTicket;
    }

    // add mapping for POST /Tickets - add new Ticket

    @PostMapping(value = "/tickets", consumes = {"application/json"})
    public @ResponseBody
    Ticket addTicket(@RequestBody Ticket theTicket) {
        // also just in case they pass an id in JSON ... set id to 0
        // this is to force a save of new item ... instead of update
        // theTicket.setTicketId(0);
        ticketService.save(theTicket);
        return theTicket;

    }

    // add mapping for PUT /Tickets - update existing Ticket

    @PutMapping(value = "/tickets", consumes = {"application/json"})
    public @ResponseBody
    Ticket updateTicket(@RequestBody Ticket theTicket) {

        ticketService.save(theTicket);

        return theTicket;
    }

    // add mapping for DELETE /Tickets/{TicketId} - delete Ticket

    @DeleteMapping("/tickets/{ticketId}")
    public String deleteTicket(@PathVariable long ticketId) {

        Ticket tempTicket = ticketService.findById(ticketId);

        // throw exception if null

        if (tempTicket == null) {
            throw new RuntimeException("Ticket id not found - " + ticketId);
        }

        ticketService.deleteById(ticketId);

        return "Deleted Ticket id - " + ticketId;

    }
}

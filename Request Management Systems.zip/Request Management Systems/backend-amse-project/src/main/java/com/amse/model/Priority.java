package com.amse.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.NaturalId;

@Entity(name = "Priority")
@Table(name = "priority")
public class Priority implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "priority_id")
    @NaturalId
    private String priorityId;

    @Column(name = "description")
    private String priorityDescription;

    @OneToMany(mappedBy = "priority", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    //@JsonManagedReference(value="ticket-priority")
    @JsonIgnore
    private List<Ticket> tickets;

    public Priority(String priorityId, String priorityDescription) {
        this.priorityId = priorityId;
        this.priorityDescription = priorityDescription;
    }

    public Priority() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getPriorityId() {
        return priorityId;
    }

    public void setPriorityId(String priorityId) {
        this.priorityId = priorityId;
    }

    public String getPriorityDescription() {
        return priorityDescription;
    }

    public void setPriorityDescription(String priorityDescription) {
        this.priorityDescription = priorityDescription;
    }


    public List<Ticket> getTickets() {
        return tickets;
    }

    public void setTickets(List<Ticket> tickets) {
        this.tickets = tickets;
    }

    @Override
    public String toString() {
        return "Priority [priorityId=" + priorityId + ", priorityDescription=" + priorityDescription + "]";
    }

}

package com.amse.service;

import com.amse.model.NewTicket;
import java.util.List;

public interface NewTicketServiceInterface {
    public List<NewTicket> findAll();

    public NewTicket findById(long theId);

    public void save(NewTicket theNewTicket);

    public void save(NewTicket theNewTicket, long ticketId);

    public void deleteById(long theId);
}

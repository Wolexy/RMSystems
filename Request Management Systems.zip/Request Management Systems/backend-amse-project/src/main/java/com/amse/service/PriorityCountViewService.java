package com.amse.service;

import com.amse.model.PriorityCount;
import com.amse.repository.PriorityCountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PriorityCountViewService implements PriorityCountViewServiceInterface {

    private PriorityCountRepository priorityCountRepository;

    @Autowired
    public PriorityCountViewService(PriorityCountRepository priorityCountRepository) {
        this.priorityCountRepository = priorityCountRepository;
    }

    @Override
    public List<PriorityCount> findAll() {
        return priorityCountRepository.findAll();
    }

}

package com.amse.service;

import com.amse.model.Ticket;
import com.amse.repository.TicketRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TicketService implements TicketServiceInterface {
    private TicketRepository ticketRepository;

    @Autowired
    public TicketService(TicketRepository ticketRepository) {
        this.ticketRepository = ticketRepository;
    }

    @Override
    public List<Ticket> findAll() {
        return ticketRepository.findAll();
    }

    @Override
    public Ticket findById(long ticketId) {
        Optional<Ticket> result = ticketRepository.findById(ticketId);
        Ticket ticket = null;
        if (result.isPresent()) {
            ticket = result.get();
        } else {
            throw new RuntimeException("Cannot find ticket id - " + ticketId);
        }
        return ticket;
    }

    @Override
    public void save(Ticket ticket) {
        ticketRepository.save(ticket);
    }

    @Override
    public void deleteById(long ticketId) {
        ticketRepository.deleteById(ticketId);
    }
}

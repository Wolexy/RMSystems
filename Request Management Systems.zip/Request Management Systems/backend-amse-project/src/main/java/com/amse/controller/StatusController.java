package com.amse.controller;


import com.amse.model.Status;
import com.amse.service.StatusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:4200")
public class StatusController {

    private StatusService statusService;

    @Autowired
    public StatusController(StatusService theStatusService) {
        statusService = theStatusService;
    }

    // expose "/statuss" and return list of statuss
    @GetMapping("/status")
    public List<Status> findAll() {
        return statusService.findAll();
    }

    // add mapping for GET /Statuss/{StatusId}

    @GetMapping("/status/{statusId}")
    public Status getStatus(@PathVariable long statusId) {

        Status theStatus = statusService.findById(statusId);

        if (theStatus == null) {
            throw new RuntimeException("Status id not found - " + statusId);
        }

        return theStatus;
    }

    // add mapping for POST /Statuss - add new Status

    @PostMapping(value = "/status", consumes = {"application/json"})
    public @ResponseBody
    Status addStatus(@RequestBody Status theStatus) {

        // also just in case they pass an id in JSON ... set id to 0
        // this is to force a save of new item ... instead of update

        // theStatus.setStatusId(null);

        statusService.save(theStatus);
        return theStatus;

    }

    // add mapping for PUT /Statuss - update existing Status

    @PutMapping(value = "/status", consumes = {"application/json"})
    public @ResponseBody
    Status updateStatus(@RequestBody Status theStatus) {

        statusService.save(theStatus);

        return theStatus;
    }

    // add mapping for DELETE /Statuss/{StatusId} - delete Status

    @DeleteMapping("/status/{statusId}")
    public String deleteStatus(@PathVariable long statusId) {

        Status tempStatus = statusService.findById(statusId);

        // throw exception if null

        if (tempStatus == null) {
            throw new RuntimeException("Status id not found - " + statusId);
        }

        statusService.deleteById(statusId);

        return "Deleted Status id - " + statusId;

    }

}

package com.amse.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.NaturalId;

@Entity(name = "SubCategory")
@Table(name = "sub_category")
public class SubCategory implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "subcategory_id")
    @NaturalId
    private String subCategoryId;

    @Column(name = "sub_category_desc")
    private String subCategoryDescription;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id", referencedColumnName = "category_id")
    //@JsonBackReference(value="subcategory-category")
    //@JsonIgnore
    private Category category;

    @OneToMany(mappedBy = "subCategory", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    //@JsonManagedReference(value="ticket-subcategory")
    @JsonIgnore
    private List<Ticket> tickets;


    public SubCategory() {
    }

    public SubCategory(String subCategoryId, Category Category, String subCategoryDescription) {
        this.subCategoryId = subCategoryId;
        this.category = Category;
        this.subCategoryDescription = subCategoryDescription;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getSubCategoryId() {
        return subCategoryId;
    }

    public void setSubCategoryId(String subCategoryId) {
        this.subCategoryId = subCategoryId;
    }

    public Category getCategoryId() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public String getSubCategoryDescription() {
        return subCategoryDescription;
    }

    public void setSubCategoryDescription(String subCategoryDescription) {
        this.subCategoryDescription = subCategoryDescription;
    }

    public List<Ticket> getTickets() {
        return tickets;
    }

    public void setTickets(List<Ticket> tickets) {
        this.tickets = tickets;
    }

    public Category getCategory() {
        return category;
    }

    @Override
    public String toString() {
        return "SubCategory [subCategoryId=" + subCategoryId + ", subCategoryDescription=" + subCategoryDescription + "]";
    }

}

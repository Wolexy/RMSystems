package com.amse.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name="PriorityCount")
@Table(name="priority_count_view")
public class PriorityCount {
    @Id
    @Column(name="priority")
    private String priority;

    @Column(name="priority_count")
    private int priorityCount;

    //No-argument constructor
    public PriorityCount() {
    }

// getters

    public String getPriority() {
        return priority;
    }

    public int getPriorityCount() {
        return priorityCount;
    }

    //overriding toString()

    @Override
    public String toString() {
        return "PriorityCount{" +
                "priority='" + priority + '\'' +
                ", priorityCount=" + priorityCount +
                '}';
    }
}

package com.amse.service;

import java.util.List;

import com.amse.model.SubCategory;

public interface SubCategoryServiceInterface {

	public List<SubCategory> findAll();

	public SubCategory findById(long theId);

	public void save(SubCategory theSubCategory);

	public void deleteById(long theId);

}

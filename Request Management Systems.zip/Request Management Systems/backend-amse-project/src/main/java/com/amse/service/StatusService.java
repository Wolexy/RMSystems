package com.amse.service;

import com.amse.model.Status;
import com.amse.repository.StatusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StatusService implements StatusServiceInterface {

    private StatusRepository statusRepository;

    @Autowired
    public StatusService(StatusRepository statusRepository) {
        this.statusRepository = statusRepository;
    }

    @Override
    public List<Status> findAll() {
        return statusRepository.findAll();
    }

    @Override
    public Status findById(long statusId) {
        Optional<Status> result = statusRepository.findById(statusId);
        Status status = null;
        if (result.isPresent()) {
            status = result.get();
        } else {
            throw new RuntimeException("Cannot find status id - " + statusId);
        }
        return status;
    }

    @Override
    public void save(Status status) {
        statusRepository.save(status);
    }

    @Override
    public void deleteById(long statusId) {
        statusRepository.deleteById(statusId);
    }
}

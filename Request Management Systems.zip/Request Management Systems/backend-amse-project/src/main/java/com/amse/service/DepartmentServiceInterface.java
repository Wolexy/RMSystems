package com.amse.service;

import java.util.List;

import com.amse.model.Department;

public interface DepartmentServiceInterface {
    public List<Department> findAll();

    public Department findById(long theId);

    public void save(Department theEmployee);

    public void deleteById(long theId);
}

package com.amse.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amse.model.SubCategory;
import com.amse.repository.SubCategoryRepository;

@Service
public class SubCategoryService implements SubCategoryServiceInterface {

    private SubCategoryRepository subCategoryRepository;

    @Autowired
    public SubCategoryService(SubCategoryRepository subCategoryRepository) {
        this.subCategoryRepository = subCategoryRepository;
    }

    @Override
    public List<SubCategory> findAll() {
        return subCategoryRepository.findAll();
    }

    @Override
    public SubCategory findById(long subCategoryId) {
        Optional<SubCategory> result = subCategoryRepository.findById(subCategoryId);
        SubCategory subCategory = null;
        if (result.isPresent()) {
            subCategory = result.get();
        } else {
            throw new RuntimeException("Cannot find subCategory id - " + subCategoryId);
        }
        return subCategory;
    }

    @Override
    public void save(SubCategory subCategory) {
        subCategoryRepository.save(subCategory);
    }

    @Override
    public void deleteById(long subCategoryId) {
        subCategoryRepository.deleteById(subCategoryId);
    }
}
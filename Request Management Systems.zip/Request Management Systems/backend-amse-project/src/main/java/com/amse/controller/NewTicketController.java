package com.amse.controller;

import com.amse.model.NewTicket;
import com.amse.service.NewTicketService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:4200")
public class NewTicketController {

	private NewTicketService newTicketService;


	@Autowired
	public NewTicketController(NewTicketService theNewTicketService) {
		newTicketService = theNewTicketService;
	}

	// expose "/newTickets" and return list of newTickets
	@GetMapping("/new_tickets")
	public List<NewTicket> findAll() {
		System.out.println(newTicketService.findAll());
		return newTicketService.findAll();
	}

	@GetMapping("/newTicketss")
	public String hi() {
		System.out.println("Hi");
		return "Hi";
	}

	// add mapping for GET /NewTickets/{NewTicketId}
//produces = MediaType.APPLICATION_JSON_VALUE
	@GetMapping("/new_tickets/{newTicketId}")
	public NewTicket getNewTicket(@PathVariable long newTicketId) {

		NewTicket theNewTicket = newTicketService.findById(newTicketId);

		if (theNewTicket == null) {
			throw new RuntimeException("NewTicket id not found - " + newTicketId);
		}

		return theNewTicket;
	}

	// add mapping for POST /NewTickets - add new NewTicket

	@PostMapping(value = "/new_tickets", consumes = { "application/json" })
	public @ResponseBody NewTicket addNewTicket(@RequestBody NewTicket theNewTicket) {

		// also just in case they pass an id in JSON ... set id to 0
		// this is to force a save of new item ... instead of update
		// theNewTicket.setNewTicketId(null);
		// setting default date
		long millis=System.currentTimeMillis();
		Date date = new java.sql.Date(millis);
		theNewTicket.setRowDate(date);   //set default rowdate
		theNewTicket.setRequestDate(date); //set requestDate to now
		theNewTicket.setApproval("AWT");  //set approval to 'Awaiting decision.
		theNewTicket.setStatus("STS01");  // set status to 'New'
		newTicketService.save(theNewTicket);
		return theNewTicket;
	}

	// add mapping for PUT /NewTickets - update existing NewTicket

	@PatchMapping(value = "/new_tickets/{id}", consumes = { "application/json" })
	public @ResponseBody NewTicket updateNewTicket(@PathVariable("id") Long id,
												   @RequestBody NewTicket theNewTicket) {
		newTicketService.save(theNewTicket, id);
		return theNewTicket;
	}

	// add mapping for DELETE /NewTickets/{NewTicketId} - delete NewTicket

	@DeleteMapping("/new_tickets/{id}")
	public String deleteNewTicket(@PathVariable long newTicketId) {

		NewTicket tempNewTicket = newTicketService.findById(newTicketId);
		// throw exception if null
		if (tempNewTicket == null) {
			throw new RuntimeException("NewTicket id not found - " + newTicketId);
		}

		newTicketService.deleteById(newTicketId);
		return "Deleted NewTicket id - " + newTicketId;

	}

}

package com.amse.controller;

import com.amse.model.Technician;
import com.amse.service.TechnicianService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:4200")
public class TechnicianController {

    private TechnicianService technicianService;

    @Autowired
    public TechnicianController(TechnicianService theTechnicianService) {
        technicianService = theTechnicianService;
    }

    // expose "/technicians" and return list of technicians
    @GetMapping("/technicians")
    public List<Technician> findAll() {
        return technicianService.findAll();
    }

    // add mapping for GET /Technicians/{TechnicianId}

    @GetMapping("/technicians/{technicianId}")
    public Technician getTechnician(@PathVariable long technicianId) {

        Technician theTechnician = technicianService.findById(technicianId);

        if (theTechnician == null) {
            throw new RuntimeException("Technician id not found - " + technicianId);
        }

        return theTechnician;
    }

    // add mapping for POST /Technicians - add new Technician

    @PostMapping(value = "/technicians", consumes = {"application/json"})
    public @ResponseBody
    Technician addTechnician(@RequestBody Technician theTechnician) {

        // also just in case they pass an id in JSON ... set id to 0
        // this is to force a save of new item ... instead of update

        // theTechnician.setTechnicianId(null);

        technicianService.save(theTechnician);

        return theTechnician;

    }

    // add mapping for PUT /Technicians - update existing Technician

    @PutMapping(value = "/technicians", consumes = {"application/json"})
    public @ResponseBody
    Technician updateTechnician(@RequestBody Technician theTechnician) {

        technicianService.save(theTechnician);

        return theTechnician;
    }

    // add mapping for DELETE /Technicians/{TechnicianId} - delete Technician

    @DeleteMapping("/technicians/{technicianId}")
    public String deleteTechnician(@PathVariable long technicianId) {

        Technician tempTechnician = technicianService.findById(technicianId);

        // throw exception if null

        if (tempTechnician == null) {
            throw new RuntimeException("Technician id not found - " + technicianId);
        }

        technicianService.deleteById(technicianId);

        return "Deleted Technician id - " + technicianId;

    }

}

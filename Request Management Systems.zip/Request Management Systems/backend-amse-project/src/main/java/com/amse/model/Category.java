package com.amse.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.NaturalId;

@Entity(name = "Category")
@Table(name = "category")
public class Category implements Serializable {

    // define model object properties
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "category_id")
    @NaturalId
    private String categoryId;

    @Column(name = "category_desc")
    private String categoryDescription;

    @OneToMany(mappedBy = "category", cascade = {CascadeType.ALL})
    //@JsonManagedReference(value="subcategory-category")
    @JsonIgnore
    private List<SubCategory> subCategories;

    @OneToMany(mappedBy = "category", cascade = {CascadeType.ALL})
    @JsonIgnore
    //@JsonManagedReference(value="ticket-category")
    private List<Ticket> tickets;

// define constructors

    public Category(String categoryId, String categoryDescription, List<SubCategory> subCategories, List<Ticket> tickets) {
        this.categoryId = categoryId;
        this.categoryDescription = categoryDescription;
        this.subCategories = subCategories;
        this.tickets = tickets;
    }

    public Category() {
    }

    public List<SubCategory> getSubCategories() {
        return subCategories;
    }

    // Define getters and setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public List<Ticket> getTickets() {
        return tickets;
    }

    public void setTickets(List<Ticket> tickets) {
        this.tickets = tickets;
    }

    public void setSubCategories(List<SubCategory> subCategories) {
        this.subCategories = subCategories;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryDescription() {
        return categoryDescription;
    }

    public void setCategoryDescription(String categoryDescription) {
        this.categoryDescription = categoryDescription;
    }

    // define toString()
    @Override
    public String toString() {
        return "Category [categoryId=" + categoryId + ", categoryDescription=" + categoryDescription + "]";
    }

}

package com.amse.service;

import com.amse.model.PriorityCount;

import java.util.List;

public interface PriorityCountViewServiceInterface {
    public List<PriorityCount> findAll();
}

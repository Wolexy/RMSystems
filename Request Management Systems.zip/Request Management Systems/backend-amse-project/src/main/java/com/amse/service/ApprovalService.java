package com.amse.service;

import java.util.List;
import java.util.Optional;

import com.amse.repository.ApprovalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amse.model.Approval;

@Service
public class ApprovalService implements ApprovalServiceInterface {

    private ApprovalRepository approvalRepository;

    @Autowired
    public ApprovalService(ApprovalRepository approvalRepository) {
        this.approvalRepository = approvalRepository;
    }

    @Override
    public List<Approval> findAll() {
        return approvalRepository.findAll();
    }

    @Override
    public Approval findById(long approvalId) {
        Optional<Approval> result = approvalRepository.findById(approvalId);
        Approval approval = null;
        if (result.isPresent()) {
            approval = result.get();
        } else {
            throw new RuntimeException("Cannot find approval id - " + approvalId);
        }
        return approval;
    }

    @Override
    public void save(Approval approval) {
        approvalRepository.save(approval);
    }

    @Override
    public void deleteById(Long approvalId) {
        approvalRepository.deleteById(approvalId);
    }
}

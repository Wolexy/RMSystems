package com.amse.controller;

import com.amse.model.Job;
import com.amse.service.JobService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:4200")
public class JobController {

    private JobService jobService;

    @Autowired
    public JobController(JobService theJobService) {
        jobService = theJobService;
    }

    // expose "/jobs" and return list of jobs
    @GetMapping("/jobs")
    public List<Job> findAll() {
        return jobService.findAll();
    }

    // add mapping for GET /Jobs/{JobId}

    @GetMapping("/jobs/{jobId}")
    public Job getJob(@PathVariable long jobId) {

        Job theJob = jobService.findById(jobId);

        if (theJob == null) {
            throw new RuntimeException("Job id not found - " + jobId);
        }

        return theJob;
    }

    // add mapping for POST /Jobs - add new Job

    @PostMapping(value = "/jobs", consumes = {"application/json"})
    public @ResponseBody
    Job addJob(@RequestBody Job theJob) {

        // also just in case they pass an id in JSON ... set id to 0
        // this is to force a save of new item ... instead of update


        // theJob.setJobId(null);

        jobService.save(theJob);

        return theJob;

    }

    // add mapping for PUT /Jobs - update existing Job

    @PutMapping(value = "/jobs", consumes = {"application/json"})
    public @ResponseBody
    Job updateJob(@RequestBody Job theJob) {

        jobService.save(theJob);

        return theJob;
    }

    // add mapping for DELETE /Jobs/{JobId} - delete Job

    @DeleteMapping("/jobs/{jobId}")
    public String deleteJob(@PathVariable long jobId) {

        Job tempJob = jobService.findById(jobId);

        // throw exception if null

        if (tempJob == null) {
            throw new RuntimeException("Job id not found - " + jobId);
        }

        jobService.deleteById(jobId);

        return "Deleted Job id - " + jobId;

    }

}

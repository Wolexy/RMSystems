package com.amse.service;

import com.amse.model.Technician;
import com.amse.repository.TechnicianRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TechnicianService implements TechnicianServiceInterface {
    private TechnicianRepository technicianRepository;

    @Autowired
    public TechnicianService(TechnicianRepository technicianRepository) {
        this.technicianRepository = technicianRepository;
    }

    @Override
    public List<Technician> findAll() {
        return technicianRepository.findAll();
    }

    @Override
    public Technician findById(long technicianId) {
        Optional<Technician> result = technicianRepository.findById(technicianId);
        Technician technician = null;
        if (result.isPresent()) {
            technician = result.get();
        } else {
            throw new RuntimeException("Cannot find technician id - " + technicianId);
        }
        return technician;
    }

    @Override
    public void save(Technician technician) {
        technicianRepository.save(technician);
    }

    @Override
    public void deleteById(long technicianId) {
        technicianRepository.deleteById(technicianId);
    }
}

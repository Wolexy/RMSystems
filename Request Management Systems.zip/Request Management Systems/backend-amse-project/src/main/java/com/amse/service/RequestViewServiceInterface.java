package com.amse.service;

import com.amse.model.RequestView;
import java.util.List;

public interface RequestViewServiceInterface {
    public List<RequestView> findAll();

    public RequestView findById(String theId);
}

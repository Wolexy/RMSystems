package com.amse.service;

import java.util.List;
import java.util.Optional;

import com.amse.repository.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amse.model.Department;

@Service
public class DepartmentService implements DepartmentServiceInterface {

    private DepartmentRepository departmentRepository;

    @Autowired
    public DepartmentService(DepartmentRepository deptRepository) {
        this.departmentRepository = deptRepository;
    }

    @Override
    public List<Department> findAll() {
        return departmentRepository.findAll();
    }

    @Override
    public Department findById(long departmentId) {
        Optional<Department> result = departmentRepository.findById(departmentId);
        Department department = null;
        if (result.isPresent()) {
            department = result.get();
        } else {
            throw new RuntimeException("Cannot find department id - " + departmentId);
        }
        return department;
    }

    @Override
    public void save(Department department) {
        departmentRepository.save(department);
    }

    @Override
    public void deleteById(long departmentId) {
        departmentRepository.deleteById(departmentId);
    }
}

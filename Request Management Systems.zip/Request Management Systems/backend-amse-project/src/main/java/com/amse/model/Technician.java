package com.amse.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.NaturalId;

@Entity(name = "Technician")
@Table(name = "technician")
public class Technician implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "technician_id")
    @NaturalId
    private String technicianId;

   // @OneToOne(cascade = CascadeType.ALL)
    @Column(name = "user_id")
    private String userId;

    @Column(name = "user_name")
    private String userName;

    @OneToMany(mappedBy = "technician", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    //@JsonManagedReference(value="ticket-technician")
    @JsonIgnore
    private List<Ticket> tickets;

    public Technician() {
    }

    public Technician(String technicianId, String userId, String userName, List<Ticket> tickets) {
        this.technicianId = technicianId;
        this.userId = userId;
        this.userName = userName;
        this.tickets = tickets;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTechnicianId() {
        return technicianId;
    }

    public void setTechnicianId(String technicianId) {
        this.technicianId = technicianId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public List<Ticket> getTickets() {
        return tickets;
    }

    public void setTickets(List<Ticket> tickets) {
        this.tickets = tickets;
    }

    @Override
    public String toString() {
        return "Technician{" +
                "id=" + id +
                ", technicianId='" + technicianId + '\'' +
                ", userId='" + userId + '\'' +
                ", userName='" + userName + '\'' +
                ", tickets=" + tickets +
                '}';
    }

}


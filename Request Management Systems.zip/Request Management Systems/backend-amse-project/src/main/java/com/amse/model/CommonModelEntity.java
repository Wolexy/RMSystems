package com.amse.model;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;

public abstract class CommonModelEntity implements Serializable {
    protected Long id;

    @Id
    @Column(name = "ID", nullable = false, precision = 22, scale = 0)
    public Long getId() {
        return id;
    }
}

package com.amse.controller;

import com.amse.model.Category;
import com.amse.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:4200")
public class CategoryController {

    private CategoryService categoryService;

    @Autowired
    public CategoryController(CategoryService theCategoryService) {
        categoryService = theCategoryService;
    }

    // expose "/categorys" and return list of categorys
    @GetMapping("/categories")
    public List<Category> findAll() {
        return categoryService.findAll();
    }

    // add mapping for GET /Categorys/{CategoryId}

    @GetMapping("/categories/{categoryId}")
    public Category getCategory(@PathVariable long categoryId) {

        Category theCategory = categoryService.findById(categoryId);

        if (theCategory == null) {
            throw new RuntimeException("Category id not found - " + categoryId);
        }

        return theCategory;
    }

    // add mapping for POST /Categorys - add new Category

    @PostMapping(value = "/categories", consumes = {"application/json"})
    public @ResponseBody
    Category addCategory(@RequestBody Category theCategory) {

        // also just in case they pass an id in JSON ... set id to 0
        // this is to force a save of new item ... instead of update

        theCategory.setCategoryId(null);

        categoryService.save(theCategory);

        return theCategory;

    }

    // add mapping for PUT /Categorys - update existing Category

    @PutMapping(value = "/categories", consumes = {"application/json"})
    public @ResponseBody
    Category updateCategory(@RequestBody Category theCategory) {

        categoryService.save(theCategory);

        return theCategory;
    }

    // add mapping for DELETE /Categorys/{CategoryId} - delete Category

    @DeleteMapping("/categories/{categoryId}")
    public String deleteCategory(@PathVariable long categoryId) {

        Category tempCategory = categoryService.findById(categoryId);

        // throw exception if null

        if (tempCategory == null) {
            throw new RuntimeException("Category id not found - " + categoryId);
        }

        categoryService.deleteById(categoryId);

        return "Deleted Category id - " + categoryId;

    }

}

package com.amse.service;

import com.amse.model.StatusCount;

import java.util.List;

public interface StatusCountViewServiceInterface {
    public List<StatusCount> findAll();
}

package com.amse.notify;
import com.mysql.cj.x.protobuf.MysqlxDatatypes;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;

@Service
@CrossOrigin(origins = "http://localhost:4200")
public class SendMessage {

    // Find your Account Sid and Token at twilio.com/user/account
    public static final java.lang.String ACCOUNT_SID = "AC7b3b71f25d758e448eecef517c90bce8";
    public static final String AUTH_TOKEN = "fe5479623c4e26abea607b9a3e73d559";

   public String sendSMS(String name, long phoneNumber, long ticketId){

       Twilio.init(ACCOUNT_SID, AUTH_TOKEN);

       Message message = Message.creator(new PhoneNumber("+19096875549"), //to
               new PhoneNumber("+18157681150"), // from
               "Hi, Helpdesk ticket " +  ticketId + " has been assigned to you, thanks.").create();

       return "Message delivered to " + name + " on " + phoneNumber;
    }
}

package com.amse.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.amse.model.Department;
import com.amse.service.DepartmentService;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:4200")
public class DepartmentController {

    private DepartmentService departmentService;

    @Autowired
    public DepartmentController(DepartmentService theDepartmentService) {
        departmentService = theDepartmentService;
    }

    // expose "/departments" and return list of departments
    @GetMapping("/departments")
    public List<Department> findAll() {
        return departmentService.findAll();
    }

    // add mapping for GET /Departments/{DepartmentId}

    @GetMapping("/departments/{departmentId}")
    public Department getDepartment(@PathVariable long departmentId) {

        Department theDepartment = departmentService.findById(departmentId);

        if (theDepartment == null) {
            throw new RuntimeException("Department id not found - " + departmentId);
        }

        return theDepartment;
    }

    // add mapping for POST /Departments - add new Department

    @PostMapping(value = "/departments", consumes = {"application/json"})
    public @ResponseBody
    Department addDepartment(@RequestBody Department theDepartment) {

        // also just in case they pass an id in JSON ... set id to 0
        // this is to force a save of new item ... instead of update
        //   theDepartment.setDepartmentId(null);
        departmentService.save(theDepartment);
        return theDepartment;

    }

    // add mapping for PUT /Departments - update existing Department

    @PutMapping(value = "/departments", consumes = {"application/json"})
    public @ResponseBody
    Department updateDepartment(@RequestBody Department theDepartment) {

        departmentService.save(theDepartment);

        return theDepartment;
    }

    // add mapping for DELETE /Departments/{DepartmentId} - delete Department

    @DeleteMapping("/departments/{departmentId}")
    public String deleteDepartment(@PathVariable long departmentId) {

        Department tempDepartment = departmentService.findById(departmentId);

        // throw exception if null

        if (tempDepartment == null) {
            throw new RuntimeException("Department id not found - " + departmentId);
        }

        departmentService.deleteById(departmentId);

        return "Deleted Department id - " + departmentId;

    }

}

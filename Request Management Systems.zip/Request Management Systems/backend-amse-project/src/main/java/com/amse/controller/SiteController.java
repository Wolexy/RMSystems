package com.amse.controller;

import com.amse.model.Site;
import com.amse.service.SiteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:4200")
public class SiteController {

    private SiteService siteService;

    @Autowired
    public SiteController(SiteService theSiteService) {
        siteService = theSiteService;
    }

    // expose "/sites" and return list of sites
    @GetMapping("/sites")
    public List<Site> findAll() {
        return siteService.findAll();
    }

    // add mapping for GET /Sites/{SiteId}

    @GetMapping("/sites/{siteId}")
    public Site getSite(@PathVariable long siteId) {

        Site theSite = siteService.findById(siteId);

        if (theSite == null) {
            throw new RuntimeException("Site id not found - " + siteId);
        }

        return theSite;
    }

    // add mapping for POST /Sites - add new Site

    @PostMapping(value = "/sites", consumes = {"application/json"})
    public @ResponseBody
    Site addSite(@RequestBody Site theSite) {

        // also just in case they pass an id in JSON ... set id to 0
        // this is to force a save of new item ... instead of update


        //  theSite.setSiteId(null);

        siteService.save(theSite);

        return theSite;

    }

    // add mapping for PUT /Sites - update existing Site

    @PutMapping(value = "/sites", consumes = {"application/json"})
    public @ResponseBody
    Site updateSite(@RequestBody Site theSite) {

        siteService.save(theSite);

        return theSite;
    }

    // add mapping for DELETE /Sites/{SiteId} - delete Site

    @DeleteMapping("/sites/{siteId}")
    public String deleteSite(@PathVariable long siteId) {

        Site tempSite = siteService.findById(siteId);

        // throw exception if null

        if (tempSite == null) {
            throw new RuntimeException("Site id not found - " + siteId);
        }

        siteService.deleteById(siteId);

        return "Deleted Site id - " + siteId;

    }

}

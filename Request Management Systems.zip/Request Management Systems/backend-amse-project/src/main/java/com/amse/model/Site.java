package com.amse.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.NaturalId;

@Entity(name = "Site")
@Table(name = "site")
public class Site implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "site_id")
    @NaturalId
    private String siteId;

    @Column(name = "location")
    private String siteLocation;

    @Column(name = "site_desc")
    private String siteDescription;

    @OneToMany(mappedBy = "site", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    //@JsonManagedReference(value="user-site")
    @JsonIgnore
    private List<User> users;

    @OneToMany(mappedBy = "site", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    //@JsonManagedReference(value="ticket-site")
    @JsonIgnore
    private List<Ticket> tickets;

    public Site(String siteId, String siteLocation, String siteDescription) {
        this.siteId = siteId;
        this.siteLocation = siteLocation;
        this.siteDescription = siteDescription;
    }

    public Site() {

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getSiteId() {
        return siteId;
    }

    public void setSiteId(String siteId) {
        this.siteId = siteId;
    }

    public String getSiteLocation() {
        return siteLocation;
    }

    public void setSiteLocation(String siteLocation) {
        this.siteLocation = siteLocation;
    }

    public String getSiteDescription() {
        return siteDescription;
    }

    public void setSiteDescription(String siteDescription) {
        this.siteDescription = siteDescription;
    }

    public List<User> getUsers() {
        return users;
    }

    public void setUsers(List<User> users) {
        this.users = users;
    }

    public List<Ticket> getTickets() {
        return tickets;
    }

    public void setTickets(List<Ticket> tickets) {
        this.tickets = tickets;
    }

    @Override
    public String toString() {
        return "Site [siteId=" + siteId + ", siteLocation=" + siteLocation + ", siteDescription=" + siteDescription
                + ", users=" + users + "]";
    }


}

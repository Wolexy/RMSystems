package com.amse.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.NaturalId;

@Entity(name = "Job")
@Table(name = "job")
public class Job implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "job_id")
    @NaturalId
    private String jobId;

    @Column(name = "job_desc")
    private String jobDescription;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "department_id", referencedColumnName = "department_id")
    //@JsonBackReference(value="job-department")
    //@JsonIgnore
    private Department department;

    @OneToMany(mappedBy = "job", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    //@JsonManagedReference(value="user-job")
    @JsonIgnore
    private List<User> users;

    @OneToMany(mappedBy = "job", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    //@JsonManagedReference(value="ticket-job")
    @JsonIgnore
    private List<Ticket> tickets;

    public Job() {

    }

    public Job(String jobId, String jobDescription, Department department, List<User> users) {
        this.jobId = jobId;
        this.jobDescription = jobDescription;
        this.department = department;
        this.users = users;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public String getJobDescription() {
        return jobDescription;
    }

    public void setJobDescription(String jobDescription) {
        this.jobDescription = jobDescription;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public List<Ticket> getTickets() {
        return tickets;
    }

    public void setTickets(List<Ticket> tickets) {
        this.tickets = tickets;
    }

    public Department getDepartmentId() {
        return department;
    }

    public void setDepartmentId(Department department) {
        this.department = department;
    }

    public List<User> getUsers() {
        return users;
    }

    public void setUsers(List<User> users) {
        this.users = users;
    }

    @Override
    public String toString() {
        return "Job [jobId=" + jobId + ", jobDescription=" + jobDescription + ", department=" + department
                + ", users=" + users + "]";
    }

}

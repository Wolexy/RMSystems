package com.amse.controller;

import com.amse.model.PriorityCount;
import com.amse.service.PriorityCountViewService;
import com.fasterxml.jackson.annotation.JsonTypeName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:4200")
//@JsonTypeName("list")
public class PriorityCountController {

    private PriorityCountViewService priorityCountViewService;

    @Autowired
    public PriorityCountController(PriorityCountViewService thePriorityCountService) {
        this.priorityCountViewService = thePriorityCountService;
    }

    // expose "/priorityCounts" and return list of priorityCounts
    @GetMapping("/priorityCounts")
    public List<PriorityCount> findAll() {
        return priorityCountViewService.findAll();
    }
}

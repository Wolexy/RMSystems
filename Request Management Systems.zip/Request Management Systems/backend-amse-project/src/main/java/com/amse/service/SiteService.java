package com.amse.service;

import com.amse.model.Site;
import com.amse.repository.SiteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SiteService implements SiteServiceInterface {

    private SiteRepository siteRepository;

    @Autowired
    public SiteService(SiteRepository siteRepository) {
        this.siteRepository = siteRepository;
    }

    @Override
    public List<Site> findAll() {
        return siteRepository.findAll();
    }

    @Override
    public Site findById(long siteId) {
        Optional<Site> result = siteRepository.findById(siteId);
        Site site = null;
        if (result.isPresent()) {
            site = result.get();
        } else {
            throw new RuntimeException("Cannot find site id - " + siteId);
        }
        return site;
    }

    @Override
    public void save(Site site) {
        siteRepository.save(site);
    }

    @Override
    public void deleteById(long siteId) {
        siteRepository.deleteById(siteId);
    }
}

package com.amse.service;

import com.amse.model.Priority;
import com.amse.repository.PriorityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PriorityService implements PriorityServiceInterface {

    private PriorityRepository priorityRepository;

    @Autowired
    public PriorityService(PriorityRepository priorityRepository) {
        this.priorityRepository = priorityRepository;
    }

    @Override
    public List<Priority> findAll() {
        return priorityRepository.findAll();
    }

    @Override
    public Priority findById(long priorityId) {
        Optional<Priority> result = priorityRepository.findById(priorityId);
        Priority priority = null;
        if (result.isPresent()) {
            priority = result.get();
        } else {
            throw new RuntimeException("Cannot find priority id - " + priorityId);
        }
        return priority;
    }

    @Override
    public void save(Priority priority) {
        priorityRepository.save(priority);
    }

    @Override
    public void deleteById(long priorityId) {
        priorityRepository.deleteById(priorityId);
    }

}

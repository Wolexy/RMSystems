package com.amse.service;

import com.amse.model.StatusCount;
import com.amse.repository.StatusCountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StatusCountViewService implements StatusCountViewServiceInterface {

    private StatusCountRepository statusCountRepository;

    @Autowired
    public StatusCountViewService(StatusCountRepository statusCountRepository) {
        this.statusCountRepository = statusCountRepository;
    }

    @Override
    public List<StatusCount> findAll() {
        return statusCountRepository.findAll();
    }
}

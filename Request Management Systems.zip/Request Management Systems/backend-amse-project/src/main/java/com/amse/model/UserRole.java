package com.amse.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.NaturalId;

//import org.springframework.security.core.GrantedAuthority;
@Entity
@Table(name = "user_role")
public class UserRole implements Serializable { //implements  GrantedAuthority

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "role_id")
    @NaturalId
    private String roleId;

    @Column(name = "role_description")
    private String roleDescription;

    @OneToMany(mappedBy = "userRole", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    //@JsonManagedReference(value="user-userrole")
    @JsonIgnore
    private List<User> users;

    public UserRole(String roleId, String roleDescription) {
        this.roleId = roleId;
        this.roleDescription = roleDescription;
    }

    public UserRole() {

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getRoleDescription() {
        return roleDescription;
    }

    public void setRoleDescription(String roleDescription) {
        this.roleDescription = roleDescription;
    }

    public List<User> getUsers() {
        return users;
    }

    public void setUsers(List<User> users) {
        this.users = users;
    }
/*
	@Override
	public String getAuthority(){
		return roleId;
	}
	@Override
	public String toString() {
		return "UserRole [roleId=" + roleId + ", roleDescription=" + roleDescription + ", users=" + users + "]";
	}
	*/
}

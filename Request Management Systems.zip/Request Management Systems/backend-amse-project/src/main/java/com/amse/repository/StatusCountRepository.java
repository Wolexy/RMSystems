package com.amse.repository;

import com.amse.model.StatusCount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StatusCountRepository extends JpaRepository<StatusCount, String> {
}

package com.amse.service;

import com.amse.model.AppUser;
import com.amse.model.User;
import com.amse.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService implements UserServiceInterface {
    private UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public List<AppUser> findAll() {
        return userRepository.findAll();
    }

    @Override
    public AppUser findById(long userId) {
        Optional<AppUser> result = userRepository.findById(userId);
        AppUser user = null;
        if (result.isPresent()) {
            user = result.get();
        } else {
            throw new RuntimeException("Cannot find user id - " + userId);
        }
        return user;
    }

    @Override
    public void save(AppUser user) {
        System.out.println(user);
        userRepository.save(user);

    }


    @Override
    public void deleteById(long userId) {
        userRepository.deleteById(userId);
    }
}
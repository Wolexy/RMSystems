package com.amse.service;

import com.amse.model.Site;

import java.util.List;

public interface SiteServiceInterface {
    public List<Site> findAll();

    public Site findById(long theId);

    public void save(Site theSite);

    public void deleteById(long theId);
}

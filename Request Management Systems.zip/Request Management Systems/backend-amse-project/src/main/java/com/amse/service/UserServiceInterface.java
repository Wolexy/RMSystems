package com.amse.service;

import com.amse.model.AppUser;
import com.amse.model.User;

import java.util.List;

public interface UserServiceInterface {
    public List<AppUser> findAll();

    public AppUser findById(long theId);

    public void save(AppUser theUser);

    public void deleteById(long theId);
}

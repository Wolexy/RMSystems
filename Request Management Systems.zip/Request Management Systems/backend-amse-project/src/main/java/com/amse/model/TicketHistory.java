package com.amse.model;

import org.hibernate.annotations.NaturalId;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.*;

@Entity
@Table(name = "ticket_history")
public class TicketHistory implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "history_id")
    @NaturalId
    private String ticketHistoryId;

    @OneToOne(cascade = {CascadeType.ALL})
    @JoinColumn(name = "ticket_id")
    // @MapsId
    private Ticket ticket;

    @Column(name = "creation_date")
    private LocalDate ticketCreatonDate;

    @Column(name = "last_update")
    private LocalDate ticketLastUpdateDate;

    @Column(name = "completed_date")
    private LocalDate ticketCompledDate;

    @Column(name = "user_id")
    private String ticketUserId;

    @Column(name = "technician_id")
    private String technicianId;

    public TicketHistory(String ticketHistoryId, Ticket ticket, LocalDate ticketCreatonDate,
                         LocalDate ticketLastUpdateDate, LocalDate ticketCompledDate, String ticketUserId, String technicianId) {
        this.ticketHistoryId = ticketHistoryId;
        this.ticket = ticket;
        this.ticketCreatonDate = ticketCreatonDate;
        this.ticketLastUpdateDate = ticketLastUpdateDate;
        this.ticketCompledDate = ticketCompledDate;
        this.ticketUserId = ticketUserId;
        this.technicianId = technicianId;
    }

    public TicketHistory() {

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTicketHistoryId() {
        return ticketHistoryId;
    }

    public void setTicketHistoryId(String ticketHistoryId) {
        this.ticketHistoryId = ticketHistoryId;
    }

    public Ticket getTicketId() {
        return ticket;
    }

    public void setTicketId(Ticket ticket) {
        this.ticket = ticket;
    }

    public LocalDate getTicketCreatonDate() {
        return ticketCreatonDate;
    }

    public void setTicketCreatonDate(LocalDate ticketCreatonDate) {
        this.ticketCreatonDate = ticketCreatonDate;
    }

    public LocalDate getTicketLastUpdateDate() {
        return ticketLastUpdateDate;
    }

    public void setTicketLastUpdateDate(LocalDate ticketLastUpdateDate) {
        this.ticketLastUpdateDate = ticketLastUpdateDate;
    }

    public LocalDate getTicketCompledDate() {
        return ticketCompledDate;
    }

    public void setTicketCompledDate(LocalDate ticketCompledDate) {
        this.ticketCompledDate = ticketCompledDate;
    }

    public String getTicketUserId() {
        return ticketUserId;
    }

    public void setTicketUserId(String ticketUserId) {
        this.ticketUserId = ticketUserId;
    }

    public String getTechnicianId() {
        return technicianId;
    }

    public void setTechnicianId(String technicianId) {
        this.technicianId = technicianId;
    }

    @Override
    public String toString() {
        return "TicketHistory [ticketHistoryId=" + ticketHistoryId + ", ticket=" + ticket + ", ticketCreatonDate="
                + ticketCreatonDate + ", ticketLastUpdateDate=" + ticketLastUpdateDate + ", ticketCompledDate="
                + ticketCompledDate + ", ticketUserId=" + ticketUserId + ", technicianId=" + technicianId + "]";
    }

}

package com.amse.error;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalRestExceptionHandler {
// Add exception handling code here

    // Add an exception handler using @ExceptionHandler
    // Basically, we create a POJO to represent ResponseEntity returned from
    // handlerException method
    @ExceptionHandler
    public ResponseEntity<CustomErrorResponse> handleException(CategoryNotFoundException exc) {

        // create a CategoryErrorResponse of type defined for ResponseEntity
        CustomErrorResponse error = new CustomErrorResponse();

        error.setStatus(HttpStatus.NOT_FOUND.value());
        error.setMessage(exc.getMessage());
        error.setTimestamp(System.currentTimeMillis());

        // return ResponseEntity
        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }

    // Add generic exception handler --- to catche all other exceptions

    @ExceptionHandler
    public ResponseEntity<CustomErrorResponse> handleException(Exception exc) {

        // create a CategoryErrorResponse of type defined for ResponseEntity
        CustomErrorResponse error = new CustomErrorResponse();

        error.setStatus(HttpStatus.BAD_REQUEST.value());
        error.setMessage("Error: Bad request");
        error.setTimestamp(System.currentTimeMillis());

        // return ResponseEntity
        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    }

}

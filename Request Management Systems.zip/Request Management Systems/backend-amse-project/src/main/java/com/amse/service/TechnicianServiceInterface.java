package com.amse.service;

import com.amse.model.Technician;

import java.util.List;

public interface TechnicianServiceInterface {

    public List<Technician> findAll();

    public Technician findById(long theId);

    public void save(Technician theTechnician);

    public void deleteById(long theId);
}

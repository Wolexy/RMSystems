package com.amse.model;

public enum RoleType {
    U001("Admin User"), U002("Regular User");

    //field
    private String value;

    //constructor
    private RoleType(String name) {
        this.value = name;
    }

    // getter method
    public String getValue() {
        return this.value;
    }
}

package com.amse.service;

import com.amse.model.Job;
import com.amse.repository.JobRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class JobService implements JobServiceInterface {

    private JobRepository jobRepository;

    @Autowired
    public JobService(JobRepository jobRepository) {
        this.jobRepository = jobRepository;
    }

    @Override
    public List<Job> findAll() {
        return jobRepository.findAll();
    }

    @Override
    public Job findById(long jobId) {
        Optional<Job> result = jobRepository.findById(jobId);
        Job job = null;
        if (result.isPresent()) {
            job = result.get();
        } else {
            throw new RuntimeException("Cannot find job id - " + jobId);
        }
        return job;
    }

    @Override
    public void save(Job job) {
        jobRepository.save(job);
    }

    @Override
    public void deleteById(long jobId) {
        jobRepository.deleteById(jobId);
    }
}

package com.amse.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDate;

@Entity(name="RequestView")
@Table(name = "request_view")
public class RequestView {
    @Id
    @Column(name="id")
    private String requestViewId;

    @Column(name="title")
    private String requestViewTitle;

    @Column(name="requester")
    private String requestViewRequester;

    @Column(name="request_date")
    private  LocalDate requestViewRequestDate;

    @Column(name="technician")
    private String requestViewTechnicianName;

    @Column(name="priority")
    private String requestViewPriority;

    @Column(name="approval")
    private String requestViewApprovalStatus;

    @Column(name="status")
    private String requestViewStatus;

    //Constructors
    public RequestView() {
    }

  //  public RequestView(String requestViewTitle, String requestViewRequester,
    //                   LocalDate requestViewRequestDate, String requestViewTechnicianName,
    //                   String requestViewPriority, String requestViewApprovalStatus, String requestViewStatus) {
    //    this.requestViewTitle = requestViewTitle;
    //    this.requestViewRequester = requestViewRequester;
    //    this.requestViewRequestDate = requestViewRequestDate;
     //   this.requestViewTechnicianName = requestViewTechnicianName;
      //  this.requestViewPriority = requestViewPriority;
      //  this.requestViewApprovalStatus = requestViewApprovalStatus;
      //  this.requestViewStatus = requestViewStatus;
   // }
    
    //getters and setters

    public String getRequestViewId() {
        return requestViewId;
    }

   // public void setRequestViewId(String requestViewId) {
    //    this.requestViewId = requestViewId;
   // }

    public String getRequestViewTitle() {
        return requestViewTitle;
    }

   // public void setRequestViewTitle(String requestViewTitle) {
   //     this.requestViewTitle = requestViewTitle;
 //   }

    public String getRequestViewRequester() {
        return requestViewRequester;
    }

  //  public void setRequestViewRequester(String requestViewRequester) {
   //     this.requestViewRequester = requestViewRequester;
   // }

    public LocalDate getRequestViewRequestDate() {
        return requestViewRequestDate;
    }

   // public void setRequestViewRequestDate(LocalDate requestViewRequestDate) {
   //     this.requestViewRequestDate = requestViewRequestDate;
   // }

    public String getRequestViewTechnicianName() {
        return requestViewTechnicianName;
    }

  //  public void setRequestViewTechnicianName(String requestViewTechnicianName) {
   //     this.requestViewTechnicianName = requestViewTechnicianName;
  //  }

    public String getRequestViewPriority() {
        return requestViewPriority;
    }

   // public void setRequestViewPriority(String requestViewPriority) {
   //     this.requestViewPriority = requestViewPriority;
   // }

    public String getRequestViewApprovalStatus() {
        return requestViewApprovalStatus;
    }

  //  public void setRequestViewApprovalStatus(String requestViewApprovalStatus) {
   //     this.requestViewApprovalStatus = requestViewApprovalStatus;
   // }

    public String getRequestViewStatus() {
        return requestViewStatus;
    }

   // public void setRequestViewStatus(String requestViewStatus) {
  //      this.requestViewStatus = requestViewStatus;
  //  }
    
    // toString

    @Override
    public String toString() {
        return "RequestView{" +
                "requestViewId='" + requestViewId + '\'' +
                ", requestViewTitle='" + requestViewTitle + '\'' +
                ", requestViewRequester='" + requestViewRequester + '\'' +
                ", requestViewRequestDate=" + requestViewRequestDate +
                ", requestViewTechnicianName='" + requestViewTechnicianName + '\'' +
                ", requestViewPriority='" + requestViewPriority + '\'' +
                ", requestViewApprovalStatus='" + requestViewApprovalStatus + '\'' +
                ", requestViewStatus='" + requestViewStatus + '\'' +
                '}';
    }
}

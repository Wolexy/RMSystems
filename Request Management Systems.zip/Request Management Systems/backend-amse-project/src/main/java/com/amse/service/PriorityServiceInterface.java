package com.amse.service;

import com.amse.model.Priority;

import java.util.List;

public interface PriorityServiceInterface {
    public List<Priority> findAll();

    public Priority findById(long theId);

    public void save(Priority thePriority);

    public void deleteById(long theId);
}

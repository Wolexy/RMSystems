package com.amse.service;

import java.util.List;

import com.amse.model.Category;

public interface CategoryServiceInterface {
    public List<Category> findAll();

    public Category findById(long theId);

    public void save(Category theCategory);

    public void deleteById(long theId);
}

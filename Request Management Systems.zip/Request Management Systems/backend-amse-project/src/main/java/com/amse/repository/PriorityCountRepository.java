package com.amse.repository;

import com.amse.model.PriorityCount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PriorityCountRepository extends JpaRepository<PriorityCount, String> {
}

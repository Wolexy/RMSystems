package com.amse.model;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.*;

@Entity(name = "Ticket")
@Table(name = "ticket")
public class Ticket implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ticket_id")
    private long ticketId;

    @Column(name = "ticket_title")
    private String ticketTitle;

    @Column(name = "ticket_description")
    private String ticketDescription;

    @Column(name = "ticket_date")
    private LocalDate ticketDate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "department_id", referencedColumnName = "department_id")
    //@JsonBackReference(value="ticket-department")
    //@JsonIgnore
    private Department department;

    @ManyToOne(cascade = CascadeType.PERSIST, fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", referencedColumnName = "user_id")
    //@JsonBackReference(value="ticket-user")
    //@JsonIgnore
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "job_id", referencedColumnName = "job_id")
    //@JsonBackReference(value="ticket-job")
    //@JsonIgnore
    private Job job;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "priority_id", referencedColumnName = "priority_id")
    //@JsonBackReference(value="ticket-priority")
    //@JsonIgnore
    private Priority priority;

    @ManyToOne(cascade = CascadeType.PERSIST, fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id", referencedColumnName = "category_id")
    //@JsonBackReference(value="ticket-category")
    //@JsonIgnore
    private Category category;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "subcategory_id", referencedColumnName = "subcategory_id")
    //@JsonBackReference(value="ticket-subcategory")
    //@JsonIgnore
    private SubCategory subCategory;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "site_id", referencedColumnName = "site_id")
    //@JsonBackReference(value="ticket-site")
    //@JsonIgnore
    private Site site;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "status_id", referencedColumnName = "status_id")
    //@JsonBackReference(value="ticket-status")
    //@JsonIgnore
    private Status status;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "technician_id", referencedColumnName = "technician_id")
    //@JsonBackReference(value="ticket-technician")
    //@JsonIgnore
    private Technician technician;

    @Column(name = "approved_by")
    private String ticketApprover;

    @Column(name = "isknown_issue")
    private boolean isKnownIssue;

    @Column(name = "related_case")
    private String ticketRelatedCase;

    public Ticket() {

    }

    public Ticket(String ticketTitle, String ticketDescription, LocalDate ticketDate, User user, Job job,
                  Priority priority, Category category, SubCategory subCategory, Site site, Status status,
                  Technician technician, Department department, String ticketApprover, boolean isKnownIssue,
                  String ticketRelatedCase) {
        this.ticketTitle = ticketTitle;
        this.ticketDescription = ticketDescription;
        this.ticketDate = ticketDate;
        this.user = user;
        this.job = job;
        this.priority = priority;
        this.category = category;
        this.subCategory = subCategory;
        this.site = site;
        this.status = status;
        this.technician = technician;
        this.department = department;
        this.ticketApprover = ticketApprover;
        this.isKnownIssue = isKnownIssue;
        this.ticketRelatedCase = ticketRelatedCase;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public long getTicketId() {
        return ticketId;
    }

    public void setTicketId(long ticketId) {
        this.ticketId = ticketId;
    }

    public String getTicketTitle() {
        return ticketTitle;
    }

    public void setTicketTitle(String ticketTitle) {
        this.ticketTitle = ticketTitle;
    }

    public String getTicketDescription() {
        return ticketDescription;
    }

    public void setTicketDescription(String ticketDescription) {
        this.ticketDescription = ticketDescription;
    }

    public LocalDate getTicketDate() {
        return ticketDate;
    }

    public void setTicketDate(LocalDate ticketDate) {
        this.ticketDate = ticketDate;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Job getJob() {
        return job;
    }

    public void setJob(Job job) {
        this.job = job;
    }

    public Priority getPriority() {
        return priority;
    }

    public void setPriority(Priority priority) {
        this.priority = priority;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public SubCategory getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(SubCategory subCategory) {
        this.subCategory = subCategory;
    }

    public Site getSite() {
        return site;
    }

    public void setSite(Site site) {
        this.site = site;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public Technician getTechnician() {
        return technician;
    }

    public void setTechnician(Technician technician) {
        this.technician = technician;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public String getTicketApprover() {
        return ticketApprover;
    }

    public void setTicketApprover(String ticketApprover) {
        this.ticketApprover = ticketApprover;
    }

    public boolean isKnownIssue() {
        return isKnownIssue;
    }

    public void setKnownIssue(boolean isKnownIssue) {
        this.isKnownIssue = isKnownIssue;
    }

    public String getTicketRelatedCase() {
        return ticketRelatedCase;
    }

    public void setTicketRelatedCase(String ticketRelatedCase) {
        this.ticketRelatedCase = ticketRelatedCase;
    }

    @Override
    public String toString() {
        return "Ticket [ticketId=" + ticketId + ", ticketTitle=" + ticketTitle + ", ticketDescription="
                + ticketDescription + ", ticketDate=" + ticketDate + ", user=" + user + ", job=" + job + ", priority="
                + priority + ", category=" + category + ", subCategory=" + subCategory + ", site=" + site + ", status="
                + status + ", technician=" + technician + ", department=" + department + ", ticketApprover="
                + ticketApprover + ", isKnownIssue=" + isKnownIssue + ", ticketRelatedCase=" + ticketRelatedCase + "]";
    }


}

package com.amse.service;

import com.amse.model.Ticket;

import java.util.List;

public interface TicketServiceInterface {
    public List<Ticket> findAll();

    public Ticket findById(long theId);

    public void save(Ticket theTicket);

    public void deleteById(long theId);
}

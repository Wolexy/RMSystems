package com.amse.model;

import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeName;

import javax.persistence.*;

@Entity(name = "Approval")
@Table(name = "approval")
//@JsonTypeName("ApprovalList")
//@JsonRootName(value = "user")
public class Approval {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="approval_id")
    private String approvalId;

    @Column(name="approval_description")
    private String approvalDescription;

    // constructors
    public Approval() {
    }

    public Approval(String approvalId, String approvalDescription) {
        this.approvalId = approvalId;
        this.approvalDescription = approvalDescription;
    }

    // getters and setters

    public Long getId() {
        return id;
    }

    public String getApprovalId() {
        return approvalId;
    }

    public void setApprovalId(String approvalId) {
        this.approvalId = approvalId;
    }

    public String getApprovalDescription() {
        return approvalDescription;
    }

    public void setApprovalDescription(String approvalDescription) {
        this.approvalDescription = approvalDescription;
    }

    // toString()

    @Override
    public String toString() {
        return "Approval{" +
                "id=" + id +
                ", approvalId='" + approvalId + '\'' +
                ", approvalDescription='" + approvalDescription + '\'' +
                '}';
    }
}

package com.amse.service;

import java.util.List;

import com.amse.model.Status;

public interface StatusServiceInterface {
    public List<Status> findAll();

    public Status findById(long theId);

    public void save(Status theStatus);

    public void deleteById(long theId);
}

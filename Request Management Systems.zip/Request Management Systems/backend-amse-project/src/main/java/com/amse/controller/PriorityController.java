package com.amse.controller;

import com.amse.model.Priority;
import com.amse.service.PriorityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:4200")
public class PriorityController {

    private PriorityService priorityService;

    @Autowired
    public PriorityController(PriorityService thePriorityService) {
        priorityService = thePriorityService;
    }

    // expose "/prioritys" and return list of prioritys
    @GetMapping("/priorities")
    public List<Priority> findAll() {
        return priorityService.findAll();
    }

    // add mapping for GET /Prioritys/{PriorityId}

    @GetMapping("/prioritys/{priorityId}")
    public Priority getPriority(@PathVariable long priorityId) {

        Priority thePriority = priorityService.findById(priorityId);

        if (thePriority == null) {
            throw new RuntimeException("Priority id not found - " + priorityId);
        }

        return thePriority;
    }

    // add mapping for POST /Prioritys - add new Priority

    @PostMapping(value = "/priorities", consumes = {"application/json"})
    public @ResponseBody
    Priority addPriority(@RequestBody Priority thePriority) {

        // also just in case they pass an id in JSON ... set id to 0
        // this is to force a save of new item ... instead of update


        // thePriority.setPriorityId(null);

        priorityService.save(thePriority);

        return thePriority;

    }

    // add mapping for PUT /Prioritys - update existing Priority

    @PutMapping(value = "/priorities", consumes = {"application/json"})
    public @ResponseBody
    Priority updatePriority(@RequestBody Priority thePriority) {

        priorityService.save(thePriority);

        return thePriority;
    }

    // add mapping for DELETE /Prioritys/{PriorityId} - delete Priority

    @DeleteMapping("/priorities/{priorityId}")
    public String deletePriority(@PathVariable long priorityId) {

        Priority tempPriority = priorityService.findById(priorityId);

        // throw exception if null

        if (tempPriority == null) {
            throw new RuntimeException("Priority id not found - " + priorityId);
        }

        priorityService.deleteById(priorityId);

        return "Deleted Priority id - " + priorityId;

    }

}

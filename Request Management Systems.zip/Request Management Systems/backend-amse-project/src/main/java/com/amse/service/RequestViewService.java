package com.amse.service;

import com.amse.model.RequestView;
import com.amse.repository.RequestViewRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RequestViewService implements RequestViewServiceInterface {

    private RequestViewRepository requestViewRepository;

    @Autowired
    public RequestViewService(RequestViewRepository requestViewRepository) {
        this.requestViewRepository = requestViewRepository;
    }

    @Override
    public List<RequestView> findAll() {
        return requestViewRepository.findAll();
    }

    @Override
    public RequestView findById(String requestViewId) {
        Optional<RequestView> result = requestViewRepository.findById(requestViewId);
        RequestView requestView = null;
        if (result.isPresent()) {
            requestView = result.get();
        } else {
            throw new RuntimeException("Cannot find requestView id - " + requestViewId);
        }
        return requestView;
    }

}

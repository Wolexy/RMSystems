package com.amse.error;

public class CustomErrorResponse {

    private int status;
    private String message;
    private long timestamp;
    private String cause;

    public CustomErrorResponse(int status, String message, String cause, long timestamp) {
        this.status = status;
        this.message = message;
        this.cause = cause;
        this.timestamp = timestamp;
    }

    public CustomErrorResponse() {
        // TODO Auto-generated constructor stub
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    
    public String getCause() {
		return cause;
	}

	public void setCause(String cause) {
		this.cause = cause;
	}

	public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
    
    

    @Override
    public String toString() {
        return "ErrorResponse [status=" + status + ", message=" + message +  ", Cause=" + cause + ", timestamp=" + timestamp + "]";
    }

}

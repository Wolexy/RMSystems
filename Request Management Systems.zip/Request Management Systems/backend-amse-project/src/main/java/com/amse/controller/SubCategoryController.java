package com.amse.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.amse.model.SubCategory;
import com.amse.service.SubCategoryService;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:4200")
public class SubCategoryController {

    private SubCategoryService subCategoryService;

    @Autowired
    public SubCategoryController(SubCategoryService theSubCategoryService) {
        subCategoryService = theSubCategoryService;
    }

    // expose "/subCategorys" and return list of subCategorys
    @GetMapping("/subCategories")
    public List<SubCategory> findAll() {
        return subCategoryService.findAll();
    }

    // add mapping for GET /SubCategorys/{SubCategoryId}

    @GetMapping("/subCategories/{subCategoryId}")
    public SubCategory getSubCategory(@PathVariable long subCategoryId) {

        SubCategory theSubCategory = subCategoryService.findById(subCategoryId);

        if (theSubCategory == null) {
            throw new RuntimeException("SubCategory id not found - " + subCategoryId);
        }

        return theSubCategory;
    }

    // add mapping for POST /SubCategorys - add new SubCategory

    @PostMapping(value = "/subCategories", consumes = {"application/json"})
    public @ResponseBody
    SubCategory addSubCategory(@RequestBody SubCategory theSubCategory) {

        // also just in case they pass an id in JSON ... set id to 0
        // this is to force a save of new item ... instead of update


        theSubCategory.setSubCategoryId(null);

        subCategoryService.save(theSubCategory);

        return theSubCategory;

    }

    // add mapping for PUT /SubCategorys - update existing SubCategory

    @PutMapping(value = "/subCategories", consumes = {"application/json"})
    public @ResponseBody
    SubCategory updateSubCategory(@RequestBody SubCategory theSubCategory) {

        subCategoryService.save(theSubCategory);

        return theSubCategory;
    }

    // add mapping for DELETE /SubCategorys/{SubCategoryId} - delete SubCategory

    @DeleteMapping("/subCategories/{subCategoryId}")
    public String deleteSubCategory(@PathVariable long subCategoryId) {

        SubCategory tempSubCategory = subCategoryService.findById(subCategoryId);

        // throw exception if null

        if (tempSubCategory == null) {
            throw new RuntimeException("SubCategory id not found - " + subCategoryId);
        }

        subCategoryService.deleteById(subCategoryId);

        return "Deleted SubCategory id - " + subCategoryId;

    }

}


package com.amse.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.amse.model.AppUser;
import com.amse.model.User;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.CrossOrigin;

@CrossOrigin("http://localhost:4200")
@Repository
public interface UserRepository extends JpaRepository<AppUser, Long> {
    // public User findByUserId(String userId);
    // public void deleteByUserId(String theId);
    // public String deleteUser(String theId);
}

package com.amse.model;

import java.io.Serializable;
import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "NewTicket")
@Table(name = "request")
//@JsonTypeName("request")  
//@JsonRootName(value = "parent")
//@JsonTypeInfo(include = JsonTypeInfo.As.WRAPPER_OBJECT, use = JsonTypeInfo.Id.NAME)
public class NewTicket implements Serializable {

	private static final long serialVersionUID = 1L;
	// Fields
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private Long id;

	@Column(name = "request_title")
	private String requestTitle;

	@Column(name = "request_description")
	private String requestDescription;

	@Column(name = "request_date")
	private Date requestDate;

	@Column(name = "department_id")
	private String department;

	@Column(name = "user_id")
	private String user;

	@Column(name = "job_id")
	private String job;

	@Column(name = "priority_id")
	private String priority;

	@Column(name = "category_id")
	private String category;

	@Column(name = "subcategory_id")
	private String subCategory;

	@Column(name = "site_id")
	private String site;

	@Column(name = "status_id")
	private String status;

	@Column(name = "technician_id")
	private String technician;

	@Column(name ="approval_id")
	private String approval;
	
	@Column(name = "approved_by")
	private String requestApprover;

	@Column(name = "isknown_issue")
	private boolean isKnownIssue;

	@Column(name = "related_case")
	private String relatedCase;

	@Column(name="contact_number")
	private String contactNumber;

	@Column(name="issue_date")
	private Date issueDate;

	@Column(name="email_to_notify")
	private String emailToNotify;

	@Column(name = "rowdate")
	private Date rowDate;

	// Constructors
	public NewTicket() {
	} // no-argument constructor

	public NewTicket(String requestTitle, String requestDescription,
					 Date requestDate, String department, String user,
					 String job, String priority, String category,
					 String subCategory, String site, String status,
					 String technician, String approval, String requestApprover,
					 boolean isKnownIssue, String relatedCase,
					 String contactNumber, Date issueDate,
					 String emailToNotify, Date rowDate) {
		this.requestTitle = requestTitle;
		this.requestDescription = requestDescription;
		this.requestDate = requestDate;
		this.department = department;
		this.user = user;
		this.job = job;
		this.priority = priority;
		this.category = category;
		this.subCategory = subCategory;
		this.site = site;
		this.status = status;
		this.technician = technician;
		this.approval = approval;
		this.requestApprover = requestApprover;
		this.isKnownIssue = isKnownIssue;
		this.relatedCase = relatedCase;
		this.contactNumber = contactNumber;
		this.issueDate = issueDate;
		this.emailToNotify = emailToNotify;
		this.rowDate = rowDate;
	}

	// getters and setters

	public static Long getSerialversionuid() {
		return serialVersionUID;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getRequestTitle() {
		return requestTitle;
	}

	public void setRequestTitle(String requestTitle) {
		this.requestTitle = requestTitle;
	}

	public String getRequestDescription() {
		return requestDescription;
	}

	public void setRequestDescription(String requestDescription) {
		this.requestDescription = requestDescription;
	}

	public Date getRequestDate() {
		return requestDate;
	}

	public void setRequestDate(Date requestDate) {
		this.requestDate = requestDate;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getSubCategory() {
		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}

	public String getSite() {
		return site;
	}

	public void setSite(String site) {
		this.site = site;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTechnician() {
		return technician;
	}

	public void setTechnician(String technician) {
		this.technician = technician;
	}

	public String getApproval() {
		return approval;
	}

	public void setApproval(String approval) {
		this.approval = approval;
	}

	public String getRequestApprover() {
		return requestApprover;
	}

	public void setRequestApprover(String requestApprover) {
		this.requestApprover = requestApprover;
	}

	public boolean isKnownIssue() {
		return isKnownIssue;
	}

	public void setKnownIssue(boolean knownIssue) {
		isKnownIssue = knownIssue;
	}

	public String getRelatedCase() {
		return relatedCase;
	}

	public void setRelatedCase(String relatedCase) {
		this.relatedCase = relatedCase;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public Date getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}

	public String getEmailToNotify() {
		return emailToNotify;
	}

	public void setEmailToNotify(String emailToNotify) {
		this.emailToNotify = emailToNotify;
	}

	public Date getRowDate() {
		return rowDate;
	}

	public void setRowDate(Date rowDate) {
		this.rowDate = rowDate;
	}

	// override toString()
	@Override
	public String toString() {
		return "NewTicket{" +
				"id=" + id +
				", requestTitle='" + requestTitle + '\'' +
				", requestDescription='" + requestDescription + '\'' +
				", requestDate=" + requestDate +
				", department='" + department + '\'' +
				", user='" + user + '\'' +
				", job='" + job + '\'' +
				", priority='" + priority + '\'' +
				", category='" + category + '\'' +
				", subCategory='" + subCategory + '\'' +
				", site='" + site + '\'' +
				", status='" + status + '\'' +
				", technician='" + technician + '\'' +
				", approval='" + approval + '\'' +
				", requestApprover='" + requestApprover + '\'' +
				", isKnownIssue=" + isKnownIssue +
				", relatedCase='" + relatedCase + '\'' +
				", contactNumber='" + contactNumber + '\'' +
				", issuDate=" + issueDate +
				", emailToNotify='" + emailToNotify + '\'' +
				", rowDate=" + rowDate +
				'}';
	}
}

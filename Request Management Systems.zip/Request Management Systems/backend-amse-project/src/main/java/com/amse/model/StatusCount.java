package com.amse.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name="StatusCount")
@Table(name="status_count_view")
public class StatusCount {

    @Id
    @Column(name="status")
    private String status;

    @Column(name="status_count")
    private String statusCount;

    // No-arg Constructor

    public StatusCount() {
    }

    //Getters
    public String getStatus() {
        return status;
    }

    public String getStatusCount() {
        return statusCount;
    }

    //to_String

    @Override
    public String toString() {
        return "StatusCount{" +
                "status='" + status + '\'' +
                ", statusCount='" + statusCount + '\'' +
                '}';
    }
}

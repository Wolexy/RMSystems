package com.amse.service;

import com.amse.model.Job;

import java.util.List;

public interface JobServiceInterface {
    public List<Job> findAll();

    public Job findById(long theId);

    public void save(Job theJob);

    public void deleteById(long theId);
}

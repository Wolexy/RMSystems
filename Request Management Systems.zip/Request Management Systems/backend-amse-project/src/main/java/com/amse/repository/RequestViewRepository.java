package com.amse.repository;

import com.amse.model.RequestView;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RequestViewRepository extends JpaRepository<RequestView, String> {

}

package com.amse.controller;

import com.amse.model.Approval;
import com.amse.service.ApprovalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:4200")
public class ApprovalController {

    private ApprovalService approvalService;

    @Autowired
    public ApprovalController(ApprovalService theApprovalService) {
        approvalService = theApprovalService;
    }

    // expose "/approvals" and return list of approvals
    @GetMapping("/approvals")
    public List<Approval> findAll() {
        return approvalService.findAll();
    }

    // add mapping for GET /Approvals/{ApprovalId}

    @GetMapping("/approvals/{approvalId}")
    public Approval getApproval(@PathVariable long approvalId) {

        Approval theApproval = approvalService.findById(approvalId);

        if (theApproval == null) {
            throw new RuntimeException("Approval id not found - " + approvalId);
        }

        return theApproval;
    }

    // add mapping for POST /Approvals - add new Approval

    @PostMapping(value = "/approvals", consumes = {"application/json"})
    public @ResponseBody
    Approval addApproval(@RequestBody Approval theApproval) {

        // also just in case they pass an id in JSON ... set id to 0
        // this is to force a save of new item ... instead of update

        //theApproval.setApprovalId(null);
        approvalService.save(theApproval);

        return theApproval;
    }

    // add mapping for PUT /Approvals - update existing Approval

    @PutMapping(value = "/approvals/{id}", consumes = {"application/json"})
    public @ResponseBody
    Approval updateApproval(@PathVariable("id") Long id, @RequestBody Approval theApproval) {
        approvalService.save(theApproval);
        return theApproval;
    }

    // add mapping for DELETE /Approvals/{ApprovalId} - delete Approval

    @DeleteMapping("/approvals/{approvalId}")
    public String deleteApproval(@PathVariable long approvalId) {

        Approval tempApproval = approvalService.findById(approvalId);

        // throw exception if null

        if (tempApproval == null) {
            throw new RuntimeException("Approval id not found - " + approvalId);
        }

        approvalService.deleteById(approvalId);

        return "Deleted Approval id - " + approvalId;

    }

}

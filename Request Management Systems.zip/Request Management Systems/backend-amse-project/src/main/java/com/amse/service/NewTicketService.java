package com.amse.service;

import com.amse.model.NewTicket;
import com.amse.repository.NewTicketRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

import java.util.List;
import java.util.Optional;
import com.amse.notify.SendMessage;

@Service
public class NewTicketService implements NewTicketServiceInterface {

    private NewTicketRepository newTicketRepository;
    private SendMessage sendMessage;

    @Autowired
    public NewTicketService(NewTicketRepository newTicketRepository,SendMessage sendMessage) {
        this.newTicketRepository = newTicketRepository;
        this.sendMessage = sendMessage;
    }

    @Override
    public List<NewTicket> findAll() {
        return newTicketRepository.findAll();
    }

    @Override
    public NewTicket findById(long newTicketId) {
        Optional<NewTicket> result = newTicketRepository.findById(newTicketId);
        NewTicket newTicket = null;
        if (result.isPresent()) {
            newTicket = result.get();
        } else {
            throw new RuntimeException("Cannot find newTicket id - " + newTicketId);
        }
        return newTicket;
    }

    @Override
    public void save(NewTicket newTicket) {
        newTicketRepository.save(newTicket);
    }

    @Override
    public void save(NewTicket theNewTicket, long ticketId) {
        String msg;  //message for Twilio
        String  twilioTechnician;
        long twilioTicketId;

        Optional<NewTicket> result = newTicketRepository.findById(ticketId);
        NewTicket newTicket = null;
        if(result.isPresent() )
            {
                //  sending sms message to the technician.
                twilioTechnician = theNewTicket.getTechnician();
               twilioTicketId = theNewTicket.getId();

                newTicket = result.get();
                newTicket.setId(theNewTicket.getId());
                newTicket.setStatus(theNewTicket.getStatus());
                newTicket.setApproval(theNewTicket.getApproval());
                newTicket.setTechnician(theNewTicket.getTechnician());
                newTicket.setPriority(theNewTicket.getPriority());

             //  msg =  sendMessage.sendSMS(twilioTechnician,9096875549L, twilioTicketId);
                newTicketRepository.save(newTicket);
            }else {
            throw new RuntimeException("Cannot find newTicket id - " + ticketId);
        }
    }

    @Override
    public void deleteById(long newTicketId) {
        newTicketRepository.deleteById(newTicketId);
    }
}

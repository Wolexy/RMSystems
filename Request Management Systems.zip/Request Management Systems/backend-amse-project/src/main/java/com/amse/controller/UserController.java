package com.amse.controller;

import com.amse.model.AppUser;
import com.amse.model.User;
import com.amse.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:4200")
public class UserController {

    private UserService userService;

    @Autowired
    public UserController(UserService theUserService) {
        userService = theUserService;
    }

    // expose "/users" and return list of users
    @GetMapping("/users")
    public List<AppUser> findAll() {
        return userService.findAll();
    }

    // add mapping for GET /Users/{UserId}

    @GetMapping("/users/{userId}")
    public AppUser getUserId(@PathVariable long userId) {

        AppUser theUser = userService.findById(userId);

        if (theUser == null) {
            throw new RuntimeException("User id not found - " + userId);
        }

        return theUser;
    }

    // add mapping for POST /Users - add new User

    @PostMapping(value = "/users", consumes = {"application/json"})
    public @ResponseBody
    AppUser addUser(@RequestBody AppUser theUser) {
        // also just in case they pass an id in JSON ... set id to 0
        // this is to force a save of new item ... instead of update
        userService.save(theUser);
        return theUser;
    }

    // add mapping for PUT /Users - update existing User

    @PutMapping(value = "/users", consumes = {"application/json"})
    public @ResponseBody
    AppUser updateUser(@RequestBody AppUser theUser) {

        userService.save(theUser);
        return theUser;
    }

    // add mapping for DELETE /Users/{UserId} - delete User

    @DeleteMapping("/users/{userId}")
    public String deleteUser(@PathVariable long userId) {

        AppUser tempUser = userService.findById(userId);

        // throw exception if null
        if (tempUser == null) {
            throw new RuntimeException("User id not found - " + userId);
        }

        userService.deleteById(userId);

        return "Deleted User id - " + userId;

    }

}

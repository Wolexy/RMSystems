package com.amse.controller;

import com.amse.model.RequestView;
import com.amse.service.RequestViewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:4200")
public class RequestViewController {
    private RequestViewService requestViewService;

    @Autowired
    public RequestViewController(RequestViewService theRequestViewService) {
        requestViewService = theRequestViewService;
    }

    // expose "/requestViews" and return list of requestViews
    @GetMapping("/requestViews")
    public List<RequestView> findAll() {
        return requestViewService.findAll();
    }

    // add mapping for GET /RequestViews/{RequestViewId}

    @GetMapping("/requestViews/{requestViewId}")
    public RequestView getRequestView(@PathVariable String requestViewId) {

        RequestView theRequestView = requestViewService.findById(requestViewId);

        if (theRequestView == null) {
            throw new RuntimeException("RequestView id not found - " + requestViewId);
        }

        return theRequestView;
    }

}

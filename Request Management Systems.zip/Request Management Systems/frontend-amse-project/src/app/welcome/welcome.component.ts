import { Component, OnInit } from '@angular/core';
import {MatButtonModule} from '@angular/material/button';
import { WelcomeDataService } from '../service/data/welcome-data.service';
import { HighchartsChartComponent } from 'highcharts-angular';
import * as Highcharts from 'highcharts';
import { WelcomeService } from './welcome.service';
import { PriorityCount } from '../service/data/classes/all-ticket';



@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.scss']
})
export class WelcomeComponent  implements OnInit {


  constructor(private service: WelcomeDataService,
              private priorityCountService: WelcomeService ) { }

  ngOnInit(): void {

   }
}

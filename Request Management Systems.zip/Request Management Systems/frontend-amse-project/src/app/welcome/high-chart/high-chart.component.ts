import { Component, OnInit, OnDestroy } from '@angular/core';
import * as Highcharts from 'highcharts';
import { PriorityCount } from 'src/app/service/data/classes/all-ticket';
import { WelcomeService } from '../welcome.service';
import { Observable, interval, Subscription } from 'rxjs';
import 'rxjs/add/operator/map';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-high-chart',
  templateUrl: './high-chart.component.html',
  styleUrls: ['./high-chart.component.scss']
})
export class HighChartComponent implements OnInit, OnDestroy {

  // Define array for JSON objects from RequestService
  priorityCounts: PriorityCount[];
  prioritySeries: number[];
  priorities: string[];

  priorityObservable: Promise<PriorityCount[]>;
  baseUrl = '';

  dataSeries1 = [5, 2, 2, 1];

   priorCount = [];
   priorCategogy = ['Critical', 'High', 'Medium', 'Low'];

  statusCount = [1, 5, 1, 1, 1];
  statusCategory = ['New', 'In Progress', 'On Hold', 'Resolved', 'Canceled'];

  title = 'myHighChartsApp';
  highcharts1 = Highcharts;
  highcharts2 = Highcharts;

  // open ticket by priority

  chartOptions1 = {
    chart: {
      type: 'column'
    },
    title: {
      text: 'Request By Priority'
    },
    subtitle: {
      text: 'This week'
    },
    xAxis: {
      categories: this.priorCategogy
    },
    yAxis: {
      title: {
        text: 'Ticket Count'
      }
    },
    series: [{
      name: 'Priority',
      data:  this.dataSeries1,   // this.priorCount, this.dataSeries1
      color:  '#FF7F50'
    }
    ]
  };
// Open ticket by status
  chartOptions2 = {
    chart: {
      type: 'column'
    },
    title: {
      text: 'Request By Status'
    },
    subtitle: {
      text: 'This week'
    },
    xAxis: {
      categories: this.statusCategory
    },
    yAxis: {
      title: {
        text: 'Ticket Count'
      }
    },
    series: [{
      name: 'Status',
      data:  this.statusCount,
      color: '#8B008B'
    }
    ]
  };

  constructor(private service: WelcomeService) { }

  ngOnInit(): void {

  }
  public ngOnDestroy(): void {  }



getPriority() {
  const temp =  [];
  return this.service.getPriorityCount()
     .subscribe(res => {
       res.forEach(element => {
         this.priorCount.push(element.priorityCount);
         temp.push(element.priorityCount); // console.log(typeof element.priorityCount);
       });
       console.log(this.priorCount);
       this.updateData(this.priorCount);
       console.log(typeof this.priorCount);
       console.log('temp = ', temp);
       this.dataSeries1 = temp;
       this.updateData(temp);
       this.updateData(this.dataSeries1);
       this.priorCount = res as any[];
       return {unsubscribe() {}};
    }, );
    }

 updateData(temp) {
    this.chartOptions1.series = [
      {
      name: 'Priority',
      data:  temp,
      color: '#FF7F50'
      }
    ];
}
}

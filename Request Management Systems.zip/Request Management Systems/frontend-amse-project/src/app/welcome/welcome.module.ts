import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { WelcomeRoutingModule } from './welcome-routing.module';
import { WelcomeComponent } from './welcome.component';
import { MaterialModule } from '../material/material.module';
import { MatButtonModule } from '@angular/material/button';
import { HighchartsChartComponent } from 'highcharts-angular';
import * as Highcharts from 'highcharts';
import { HighChartComponent } from './high-chart/high-chart.component';
import { HighchartsChartModule } from 'highcharts-angular';


@NgModule({
  declarations: [WelcomeComponent, HighChartComponent],

  imports: [MaterialModule, MatButtonModule,
    CommonModule, WelcomeRoutingModule,
    HighchartsChartModule
  ],
  exports: [WelcomeComponent]
})
export class WelcomeModule {

}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
import { PriorityCount, StatusCount
} from 'src/app/service/data/classes/all-ticket';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import 'rxjs/add/operator/map';



@Injectable({
  providedIn: 'root'
})
export class WelcomeService {

// Define url and REST APIs for backend - my regular work
  private baseUrl = 'http://localhost:8080/api/';

  priorityCountObject: Observable<PriorityCount[]>;
  statusCountObject: Observable<StatusCount[]>;
  priorityCnt: any;

  constructor(private http: HttpClient) { }

  retrieveAllRequest(username) {
    return this.http.get<Request[]>(`http://localhost:8080/api/tickets`);
  }

  // Define getMethods for handshake with REST API for each object for HighChart
  getPriorityCount() {
    this.priorityCountObject = this.http.get<PriorityCount[]>(this.baseUrl + 'priorityCounts');
    console.log(this.priorityCountObject);
    return this.priorityCountObject;
  }

  getPriorityCnt() {
 return  this.http.get<PriorityCount[]>(this.baseUrl + 'priorityCounts')
      .pipe(map((res: PriorityCount[]) => res));
     }

  getStatusCount(): Observable<StatusCount[]> {
    this.statusCountObject = this.http.get<StatusCount[]>(this.baseUrl + 'statusCounts');
    console.log(this.statusCountObject);
    return this.statusCountObject;
  }
}



import { Component, OnInit } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { AdminService } from '../admin.service';
import { MaterialModule } from '../../material/material.module';
import {  NgForm, FormBuilder,  FormGroup, FormArray,
  FormControl, ValidatorFn, Validators} from '@angular/forms';
import {
  Priority, User, Job, Department, Site, Category,
  SubCategory, Technician, Ticket, Status, Approval
} from 'src/app/service/data/classes/all-ticket';
import { from } from 'rxjs';

/*
export class Approval {
  constructor(
    public approvalId: number,
    public title: string,

  ) {}
} */


@Component({
  selector: 'app-triage',
  templateUrl: './triage.component.html',
  styleUrls: ['./triage.component.scss']
})
export class TriageComponent implements OnInit {
/* create hardcoded object of Approval
    approval = [
    new Approval(0, 'Not Approved'),
    new Approval (1, 'Approved')
    ];
*/
  // Define array for JSOn objects from RequestService
  priorities = new Array<Priority>();
  technicians = new Array<Technician>();
  tickets = new Array<Ticket>();
  status = new Array<Status>();
  user = new Array<User>();
  approvals = new Array<Approval>();

  ticketCount: number;
  ticket: Ticket; // for ticket update
 // id: number;     // ticketId

  // define variable for username
  userName: string;

  // define formGroup object
  triageForm = this.adminService.triage;

  constructor( private route: ActivatedRoute, public router: Router, public adminService: AdminService) { }

  ngOnInit(): void {

    this.listTickets();
    this.listPriorities();
    this.listTechnicians();
    this.listApprovals();
    this.listStatus();
    this.ticketCount = this.tickets.length;
// update ticket (triage)
  //  this.ticket = new Ticket();
/*
    this.id = this.route.snapshot.params[`id`];

    this.adminService.getTicket(this.id)
      .subscribe(data => {
        console.log(data);
        this.ticket = data;
      }, error => console.log(error));
    console.log('Id: ' + this.id); */

  }

  cancelButton = function() {
    this.router.navigateByUrl('/welcome');
  };

  // Subscribe to the observables in the AdminService
  // for priority list
  listPriorities() {
    this.adminService.getPriorities().subscribe(
      data => {
        console.log('Data: ', data);
        this.priorities = data;
      },
      error => console.log('in error in priority: ', error),
      () => console.log('Priority Observable is now complete.')
    );
  }
  // Subscribe to the observables in the AdminService
  // for  technician list
  listTechnicians() {
    this.adminService.getTechnicians().subscribe(
      data => {
        console.log('Data: ', data);
        this.technicians = data;
      },
      error => console.log('in error in technician: ', error),
      () => console.log('Technician Observable is now complete.')
    );
  }

  // Subscribe to the observables in the AdminService
  // for  approval list
  listApprovals() {
    this.adminService.getApprovals().subscribe(
      data => {
        console.log('Data: ', data);
        this.approvals = data;
      },
      error => console.log('in error in approval: ', error),
      () => console.log('Approval Observable is now complete.')
    );
  }
    // Subscribe to the observables in the AdminService
  // for  ticket list
  listTickets() {
    this.adminService.getTickets().subscribe(
      data => {
        console.log('Data: ', data);
        this.tickets = data;
      },
      error => console.log('in error in tickets: ', error),
      () => console.log('Ticket Observable is now complete.')
    );
  }
    // Subscribe to the observables in the AdminService
  // for  status list
  listStatus() {
    this.adminService.getStatus().subscribe(
      data => {
        console.log('Data: ', data);
        this.status = data;
      },
      error => console.log('in error in status: ', error),
      () => console.log('Status Observable is now complete.')
    );
  }

  // return username when passed userId

   getUserName(myUserId: string) {
    for (const value of this.user) {
      if (value.userId === myUserId) {
        this.userName = value.firstName + ' ' + value.lastName;
      }
    }
    console.log(this.userName);
    return this.userName;
   }

  // subscribe to triage form
   createUser() {
    this.adminService.createUser(this.triageForm.value).subscribe(
      data => console.log(data), error => console.log(error));
    // this.user = new User();
    // this.gotoUser();
  }

  // update ticket (triage)
  updateTicket(id: string) {
    console.log('ID is: ' + id);
    console.log('this.triageForm.value is: ' + this.triageForm.value);
    this.adminService.updateTicket(id, this.triageForm.value).subscribe(
      data => {
        console.log('Ticket -: ', data, this.triageForm.value), console.error('error');
      // reload the current page
        this.reloadComponent();
        this.triageForm.reset();
}
    );
  }
  reloadComponent() {
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    this.router.onSameUrlNavigation = 'reload';
    this.router.navigate(['/triage']);
  }
}

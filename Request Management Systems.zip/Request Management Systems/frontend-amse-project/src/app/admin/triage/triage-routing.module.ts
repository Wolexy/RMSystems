import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { TriageComponent } from './triage.component';

const routes: Routes = [
  {
    path: 'triage',
    component: TriageComponent,
    data: {showSidebar: true}
  }
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  exports: [
    RouterModule
   ]
})
export class TriageRoutingModule { }


import { Component, OnInit } from '@angular/core';
import { NgForm, FormGroup } from '@angular/forms';
import { MaterialModule } from '../../material/material.module';
import { AdminService } from '../admin.service';
import { Router, ActivatedRoute } from '@angular/router';
import {Priority, User, Job, Department, Site} from 'src/app/service/data/classes/all-ticket';
import { RequestService } from '../../request/request.service';
// import { RequestComponent } from '../../request/request.component';
import { from } from 'rxjs';

export class RoleType {
  constructor(
    public roleId: string,
    public roleDescription: string,

  ) {}
}



@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit {

// Define array for JSON objects from RequestService
  jobs = new Array<Job>();
  departments = new Array<Department>();
  sites = new Array<Site>();
  user: User = new User();

  submitted = false;
  // create object of Role type
 roleType = [
  new RoleType('U001', 'Admin User'),
  new RoleType ('U002', 'Regular User')
 ];

  // define formGroup object
  userForm = this.userAccount.form;

  constructor(public userAccount: AdminService,
              public router: Router, public requestService: RequestService
             ) { }

  ngOnInit(): void {
    this.listJobs();
    this.listDepartments();
    this.listSites();
  }

  cancelButton = function() {
    this.router.navigateByUrl('/welcome');
  };

 // Subscribe to the observables in the RequestService
// for job list
listJobs() {
  this.requestService.getJobs().subscribe(
    data => {
      console.log('Data: ', data);
      this.jobs = data;
    },
    error => console.log('in error in job: ', error),
    () => console.log('Job Observable is now complete.')
  );
}
  // Subscribe to the observables in the RequestService
  // for department list
listDepartments() {
  this.requestService.getDepartments().subscribe(
    data => {
      console.log('Data: ', data);
      this.departments = data;
    },
    error => console.log('in error in department: ', error),
    () => console.log('Departments Observable is now complete.')
  );
}
// Subscribe to the observables in the RequestService
  // for site list
listSites() {
  this.requestService.getSites().subscribe(
    data => {
      console.log('Data: ', data);
      this.sites = data;
    },
    error => console.log('in error in site: ', error),
    () => console.log('Site Observable is now complete.')
  );
}
// New employee
newUser(): void {
 // this.submitted = false;
 // this.user = new User();
}
  createUser() {
    this.userAccount.createUser(this.userForm.value).subscribe(
      data => console.log(data), error => console.log(error));
    // this.user = new User();
    // this.gotoUser();
  }

  onSubmit() {
   // this.submitted = false;
    if (this.userForm.valid) {
      this.createUser();
      alert('User record created successfully!');
    } else {
      alert('Error - please enter correct information');
    }
  }

  gotoUser() {
    this.router.navigate(['/user']);
  }

}

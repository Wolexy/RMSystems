import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { TriageComponent } from './triage/triage.component';
import { UserComponent } from './user/user.component';
import { NgForm, FormBuilder,  FormGroup, FormArray,
  FormControl, ValidatorFn, Validators,  FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminService } from './admin.service';
import { UserRoutingModule } from './user/user-routing.module';
import { TriageRoutingModule } from './triage/triage-routing.module';
import { MaterialModule } from '../material/material.module';

@NgModule({
  declarations: [TriageComponent],
  imports: [
    CommonModule,
    UserRoutingModule,
    TriageRoutingModule,
    MaterialModule,
    BrowserModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [AdminService]
})
export class AdminModule { }

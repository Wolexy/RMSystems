import { Injectable } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { HttpClient, HttpHeaders, HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Ticket, Priority, User, Job, Status, Approval,
  Department, Site, Category, SubCategory, Technician
} from 'src/app/service/data/classes/all-ticket';
import { map } from 'rxjs/operators';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable({
  providedIn: 'root'
})
export class AdminService {


  // to collect object from observable - API (connection with Java REST API)
  private baseUrl = 'http://localhost:8080/api/';
  priorityObject: Observable<Priority[]>;
  userObject: Observable<User[]>;
  jobObject: Observable<Job[]>;
  departmentObject: Observable<Department[]>;
  siteObject: Observable<Site[]>;
  categoryObject: Observable<Category[]>;
  subCategoryObject: Observable<SubCategory[]>;
  technicianObject: Observable<Technician[]>;
  ticketObject: Observable<Ticket[]>;
  statusObject: Observable<Status[]>;
  approvalObject: Observable<Approval[]>;

  constructor(private http: HttpClient) { }
// for create user
  form: FormGroup = new FormGroup({
    $key: new FormControl(null),
    userId: new FormControl('', Validators.required),
    firstName: new FormControl('', Validators.required),
    lastName: new FormControl('', Validators.required),
    email: new FormControl('', [Validators.required, Validators.email, Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]),
    phoneNumber: new FormControl(''),
    username: new FormControl('', Validators.required),
    jobId: new FormControl('', Validators.required),
    departmentId: new FormControl('', Validators.required),
    siteId: new FormControl('', Validators.required),
    roleId: new FormControl('', Validators.required),
  });


// Ticket Triage formGroup
  triage: FormGroup = new FormGroup({
  id:       new FormControl(''),
  technician: new FormControl(''),
  priority: new FormControl(''),
  approval: new FormControl(''),
  status: new FormControl('')
});

    // Define getMethods for each object filtering (to populate dropdown menus)
 // 1. For Technician
    getTechnicians(): Observable<Technician[]> {
      this.technicianObject = this.http.get<Technician[]>(this.baseUrl + 'technicians');
      console.log(this.technicianObject);
      return this.technicianObject;
    }
 // 2. For Priority
    getPriorities(): Observable<Priority[]> {
      this.priorityObject = this.http.get<Priority[]>(this.baseUrl + 'priorities');
      console.log(this.priorityObject);
      return this.priorityObject;
    }

  // 3. For Approval
  getApprovals(): Observable<Approval[]> {
    this.approvalObject = this.http.get<Approval[]>(this.baseUrl + 'approvals');
    console.log(this.approvalObject);
    return this.approvalObject;
  }

// 4. For Status
    getStatus(): Observable<Status[]> {
      this.statusObject = this.http.get<Status[]>(this.baseUrl + 'status');
      console.log(this.statusObject);
      return this.statusObject;
    }
// 5. For the whole triage page
  getTickets(): Observable<Ticket[]> {
    this.ticketObject = this.http.get<Ticket[]>(this.baseUrl + 'new_tickets');
    console.log(this.technicianObject);
    return this.ticketObject;
  }

// For user object  (Admin > create user)
  createUser(user: User): Observable<any> {
    const headers = { 'content-type': 'application/json' };
    const body = JSON.stringify(user);
    console.log(body);
    return this.http.post(`${this.baseUrl}users`, user, {headers});
  }
 // getTicket by Id
    getTicket(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}new_tickets/${id}`);
}

  // update triage page
  updateTicket(id: string, ticket: Ticket): Observable<any> {
    const headers = { 'content-type': 'application/json' };
    const body = JSON.stringify(ticket);
    ticket.id = id;
    console.log(ticket);

    return this.http.patch(`${this.baseUrl}new_tickets/${id}`, ticket, { headers });
  }

  // private handleError(error: HttpErrorResponse) {
   // return Observable.throw(error);
  // }


}

import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { FormsModule } from '@angular/forms';
import { Pipe, PipeTransform } from '@angular/core';

export class Request {
  constructor(
    public requestId: number,
    public subject: string,
    public requester: string,
    public approvedBy: string,
    public technician: string,
    public requestType: string,
    public status: string,
    public requestDate: Date,
    public closeDate: Date
  ) {}
}

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  requests = [
    new Request(
      1,
      'Project One',
      'John Doe',
      'MD',
      'Kola',
      'Service Request',
      'open',
      new Date(),
      new Date()
    ),
    new Request(
      2,
      'Project Two',
      'Sue',
      'MD',
      'Wole',
      'Document Request',
      'open',
      new Date(),
      new Date()
    ),
    new Request(
      3,
      'Project Three',
      'Terry',
      'MD',
      'Ajala',
      'Service Request',
      'open',
      new Date(),
      new Date('2020/03/15')
    )
  ];

  constructor() {}

  ngOnInit(): void {}
}

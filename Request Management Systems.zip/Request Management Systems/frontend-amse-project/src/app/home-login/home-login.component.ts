import { Component, OnInit, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormGroup,
  FormControl,
  Validators,
  FormsModule
} from '@angular/forms';
import { Router } from '@angular/router';
import { HardcodedAuthService } from 'src/app/service/hardcoded-auth.service';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'home-login',
  templateUrl: './home-login.component.html',
  styleUrls: ['./home-login.component.scss']
})
export class HomeLoginComponent implements OnInit {
  color = '#2f4f4f';
  signin: FormGroup = new FormGroup({
    email: new FormControl('', [Validators.email, Validators.required]),
    password: new FormControl('', [Validators.required, Validators.min(3)])
  });
  adjustedHeight: any;
  hide = true;
  pword = 'amse';
  email = 'amse';
  errorMessage = 'Invalid Credentials';
  invalidLogin: any;

  get emailInput() {
    return this.signin.get('email');
  }
  get passwordInput() {
    return this.signin.get('password');
  }

  constructor(
    private router: Router,
    private hardcodedAuthService: HardcodedAuthService
  ) {
    this.adjustedHeight = (.73 * window.screen.height) + 'px';
  }

  ngOnInit(): void {}

  login(): void {
    if (this.hardcodedAuthService.authenticate(this.email, this.pword)) {
      this.router.navigateByUrl('/welcome');
      this.invalidLogin = false;
    } else {
      this.invalidLogin = true;
    }
  }

  cancel(): void {
    console.log('Cancel');
  }
}

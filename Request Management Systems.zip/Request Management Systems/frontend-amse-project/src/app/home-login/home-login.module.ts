import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { HomeLoginRoutingModule } from './home-login-routing.module';
import { HomeLoginComponent } from './home-login.component';
import { MaterialModule } from '../material/material.module';

@NgModule({
  declarations: [HomeLoginComponent],
  imports: [
   CommonModule,
    HomeLoginRoutingModule,
    MaterialModule,
    FormsModule
  ],
  exports: [
    CommonModule,
    MaterialModule,
    HomeLoginComponent
  ]
})
export class HomeLoginModule { }

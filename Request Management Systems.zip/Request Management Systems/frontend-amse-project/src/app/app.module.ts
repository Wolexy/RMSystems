import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FormGroup, FormControl } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FlexLayoutModule } from '@angular/flex-layout';



import 'hammerjs';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

// imports custom modules (components & material features)
import { MaterialModule } from './material/material.module';
import { LoginModule } from './login/login.module';
import { LayoutModule } from './layout/layout.module';
import { WelcomeModule } from './welcome/welcome.module';
import { RequestModule } from './request/request.module';
import { HomeModule } from './home/home.module';
import { HomeLoginModule} from './home-login/home-login.module';
import { ContactUsModule } from './contact-us/contact-us.module';
import { RequestService } from './request/request.service';
import { ErrorComponent } from './error/error.component';
import { LogoutComponent } from './logout/logout.component';
import { UserComponent } from './admin/user/user.component';
import { AdminModule } from './admin/admin.module';
import { WelcomeService } from './welcome/welcome.service';






@NgModule({
  declarations: [
    AppComponent,
    ErrorComponent,
    LogoutComponent,
    UserComponent


  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot([]),
    AppRoutingModule,
    LayoutModule,
    WelcomeModule,
    ContactUsModule,
    LoginModule,
    HomeLoginModule,
    HomeModule,
    RequestModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    AdminModule


  ],
  providers: [RequestService, WelcomeService],
  bootstrap: [AppComponent]
})
export class AppModule { }

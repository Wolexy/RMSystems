import { Injectable } from '@angular/core';


@Injectable({
  providedIn: 'root'
})
export class HardcodedAuthService {

  constructor() { }

  authenticate(username, password) {
   // console.log('before: ' + this.isUserLoggedIn());
    if (password === 'amse' &&
      (username === 'amse' ||
        username === 'kolaajala@yahoo.com')) {
      sessionStorage.setItem('authenticatedUser', username);
    //  console.log('after: ' + this.isUserLoggedIn());
      return true;
      // this.router.navigateByUrl('/login');
    } else {
      return false;
    }

  }
  isUserLoggedIn() {
    const user = sessionStorage.getItem('authenticatedUser');
    return !(user === null);
  }

  logout() {
    sessionStorage.removeItem('authenticatedUser');
  }
}

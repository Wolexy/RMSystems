import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';



@Injectable({
  providedIn: 'root'
})
export class RequestDataService {

  constructor(private htttp: HttpClient) { }

  retrieveAllRequests() {
    return this.htttp.get<Request>('http://localhost:8080/api/tickets');
  }
}

import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map, catchError } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class WelcomeDataService {

  localHttpResult: any;
  private baseUrl = 'http://localhost:8080';

  constructor(private http: HttpClient) { }

  retrieveAllTicket() {
    return this.http.get(this.baseUrl + '/api/tickets');
  }

  getTickets(response: Response): Ticket[] {
    return null;
  }

}

export interface Ticket {
  id: string;
  subject: string;
  description: string;
  ticketDate: Date;
  userId: string;
  jobId: string;
  priorityId: string;
  categoryId: string;
  SubCategoryId: string;
  siteId: string;
  status: string;
  technicianId: string;
  departmentId: string;
  approverId: string;
  isKnown: boolean;
  relatedTickedNo: number;
  createdDate: Date;
}

export class Ticket {
  id: string;
  requestTitle: string;
  requestDescription: string;
  requestDate: Date;
  user: string;
  job: string;
  priority: string;
  category: string;
  subCategory: string;
  site: string;
  status: string;
  technician: string;
  department: string;
  requestApprover: string;
  knownIssue: boolean;
  relatedCase: number;
  approval: string;
  rowDate: Date;
}

export class RequestView {
  id: string;
  requestTitle: string;
  user: string;
  requestDate: Date;
  technician: string;
  priority: string;
  requestApprover: string;
  status: string;
}

export class Priority {
  priorityId: string;
  priorityDescription: string;
}

export class User {
  userId: string;
  firstName: string;
  lastName: string;
  departmentId: string;
  username: string;
  email: string;
  password: string;
  phoneNumber: string;
  roleId: string;
  siteId: string;
  jobId: string;
}
export class Job {
  jobId: string;
  jobDescription: string;
}
export class Department {
  departmentId: string;
  departmentName: string;
}
export class Site {
  siteId: string;
  siteLocation: string;
}

export class Category {
  categoryId: string;
  categoryDescription: string;
}
export class SubCategory {
  subCategoryId: string;
  subCategoryDescription: string;
}

export class Technician {
  technicianId: string;
  userId: string;
  userName: string;
}

export class Approval {
  approvalId: string;
  approvalDescription: string;
}


export class Status {
  statusId: string;
  statusDescription: string;
}

export class PriorityCount {
  priority: string;
  priorityCount: number;
}

export class PriorityModel {
  critical: string;
  high: string;
  medium: string;
  low: string;

}

export class StatusCount {
  status: string;
  countBystatus: number;
}


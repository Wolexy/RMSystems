import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgxMaskModule, IConfig } from 'ngx-mask';
import { RequestRoutingModule } from './request-routing.module';
import { RequestListRoutingModule } from './request-list/request-list-routing.module';
import { UnassignedRequestRoutingModule } from './unassigned-request/unassigned-requests-routing.module';
import { RequestComponent } from './request.component';
import { RequestService } from './request.service';
import { MaterialModule } from '../material/material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RequestListComponent } from './request-list/request-list.component';
import { UnassignedRequestComponent } from './unassigned-request/unassigned-request.component';




@NgModule({
  declarations: [RequestComponent,
    RequestListComponent,
    UnassignedRequestComponent
 ],
  imports: [
    CommonModule,
    RequestRoutingModule,
    UnassignedRequestRoutingModule,
    RequestListRoutingModule,
    RequestListRoutingModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    MatToolbarModule,
    BrowserAnimationsModule,
    MatCheckboxModule,
    NgxMaskModule
  ],
  providers: [RequestService]
})
export class RequestModule { }

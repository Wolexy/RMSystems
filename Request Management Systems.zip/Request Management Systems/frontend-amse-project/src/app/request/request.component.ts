import { Component, OnInit } from '@angular/core';
import { RequestService } from './request.service';
import { MaterialModule } from '../material/material.module';
import { MatToolbarModule } from '@angular/material/toolbar';
import { NgxMaskModule, IConfig } from 'ngx-mask';
import { Router, ActivatedRoute } from '@angular/router';
import {Priority, User, Job, Department, Site, Category, Ticket, SubCategory
} from 'src/app/service/data/classes/all-ticket';
import {
  NgForm, FormBuilder,
  FormGroup, FormArray,
  FormControl, ValidatorFn, Validators
} from '@angular/forms';
import { RequestListService } from './request-list/request-list.service';

@Component({
  selector: 'app-request',
  templateUrl: './request.component.html',
  styleUrls: ['./request.component.scss']
})
export class RequestComponent implements OnInit {

  checked = false;
  id: number;
  request: Request;
  // Define array for JSON objects from RequestService
  priorities = new Array<Priority>();
  users = new Array<User>();
  jobs = new Array<Job>();
  departments = new Array<Department>();
  sites = new Array<Site>();
  categories = new Array<Category>();
  subCategories = new Array<SubCategory>();

    // define formGroup object - uses formGroup defined in RequestService.ts
    requestForm = this.requestService.form;


  constructor(public requestListService: RequestListService,
              public requestService: RequestService,
              public router: Router,
              private route: ActivatedRoute,
              private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.listPriorities();
    this.listUsers();
    this.listJobs();
    this.listDepartments();
    this.listSites();
    this.listCategories();
    this.listSubCategories();
  }

  // Subscribe to the observables in the RequestService
  // for priority list
  listPriorities() {
    this.requestService.getPriorities().subscribe(
      data => {
        console.log('Data: ', data);
        this.priorities = data;
      },
      error => console.log('in error in priority: ', error),
      () => console.log('Priority Observable is now complete.')
    );
  }
  // Subscribe to the observables in the RequestService
// for user list
listUsers() {
  this.requestService.getUsers().subscribe(
    data => {
      console.log('Data: ', data);
      this.users = data;
    },
    error => console.log('in error in user: ', error),
    () => console.log('User Observable is now complete.')
  );
}
// Subscribe to the observables in the RequestService
// for job list
listJobs() {
  this.requestService.getJobs().subscribe(
    data => {
      console.log('Data: ', data);
      this.jobs = data;
    },
    error => console.log('in error in job: ', error),
    () => console.log('Job Observable is now complete.')
  );
}
// Subscribe to the observables in the RequestService
  // for department list
listDepartments() {
  this.requestService.getDepartments().subscribe(
    data => {
      console.log('Data: ', data);
      this.departments = data;
    },
    error => console.log('in error in department: ', error),
    () => console.log('Departments Observable is now complete.')
  );
}
// Subscribe to the observables in the RequestService
  // for site list
listSites() {
  this.requestService.getSites().subscribe(
    data => {
      console.log('Data: ', data);
      this.sites = data;
    },
    error => console.log('in error in site: ', error),
    () => console.log('Site Observable is now complete.')
  );
}
  // Subscribe to the observables in the RequestService
// for category list
listCategories() {
  this.requestService.getCategories().subscribe(
    data => {
      console.log('Data: ', data);
      this.categories = data;
    },
    error => console.log('in error in category: ', error),
    () => console.log('Category Observable is now complete.')
  );
}
// Subscribe to the observables in the RequestService
  // for sub category list
listSubCategories() {
  this.requestService.getSubCategories().subscribe(
    data => {
      console.log('Data: ', data);
      this.subCategories = data;
    },
    error => console.log('in error in sub-category: ', error),
    () => console.log('Sub-category Observable is now complete.')
  );
}

  // New Ticket
newTicket(): void {
  // this.submitted = false;
  // this.user = new User();
 }
   createTicket() {
     this.requestService.createTicket(this.requestForm.value).subscribe(
       data => console.log(data), error => console.log(error));
     // this.user = new User();
     // this.gotoRequest();
   }

  // submit form request
   onSubmit() {
    // this.submitted = false;
     if (this.requestForm.valid) {
       this.createTicket();
       this.requestForm.reset();
       alert('Request created successfully!');
       this.reloadComponent();  // reload the page
       this.requestService.form.reset();  // reset the form
     } else {
      alert('Error: Please check!');
     }
   }

   gotoRequest() {
     this.router.navigate(['/user-request']);
   }

   cancelButton = function() {
    this.router.navigateByUrl('/welcome');
  };

  resetButton = function() {
    this.requestForm.reset();
  };

  reloadComponent() {
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    this.router.onSameUrlNavigation = 'reload';
    this.router.navigate(['/request']);
  }
}

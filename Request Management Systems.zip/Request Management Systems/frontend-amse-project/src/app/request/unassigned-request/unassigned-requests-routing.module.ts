import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UnassignedRequestComponent } from './unassigned-request.component';

const routes: Routes = [
  {
    path: 'unassigned',
    component: UnassignedRequestComponent,
    data: {showSidebar: true}
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
 export class UnassignedRequestRoutingModule { }

import { Component, OnInit } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FormGroup, FormControl } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FlexLayoutModule } from '@angular/flex-layout';


@Component({
  selector: 'app-unassigned-request',
  templateUrl: './unassigned-request.component.html',
  styleUrls: ['./unassigned-request.component.scss']
})
export class UnassignedRequestComponent implements OnInit {

  errorMessage = 'An error occured! Contact support at ***';
  constructor() { }

  ngOnInit(): void {

  }

}

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Ticket, RequestView } from 'src/app/service/data/classes/all-ticket';
import { map } from 'rxjs/operators';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};


@Injectable({
  providedIn: 'root'
})
export class RequestListService {

  private baseUrl = 'http://localhost:8080/api/new_tickets';
  private reqView = 'http://localhost:8080/api/requestViews';


  result: Observable<Ticket[]>;
  resultView: Observable<RequestView[]>;

  constructor(private httpClient: HttpClient) {
    console.log('Hello there!!!');

   }

  getAllTickets(): Observable<Ticket[]> {
    this.result = this.httpClient.get<Ticket[]>(this.baseUrl);
    console.log(this.result);
    return this.result;

  }
  getRequestView(): Observable<RequestView[] > {
    this.resultView = this.httpClient.get<RequestView[]>(this.reqView);
    console.log(this.resultView);
    return this.resultView;
    }

}


import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RequestListComponent } from './request-list.component';
import { RouteGuardService } from '../../service/route-guard.service';
import { RequestComponent } from '../request.component';

const routes: Routes = [
  {
    path: 'user-request',
    component: RequestListComponent,  canActivate: [RouteGuardService],
    data: {showSidebar: true}
  } ,
   {
   path: 'requests/:id',
  component: RequestComponent, canActivate: [RouteGuardService]
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
 export class RequestListRoutingModule { }

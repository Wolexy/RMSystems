import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RequestRoutingModule } from '../request-routing.module';
import { RequestComponent } from '../request.component';
import { RequestService } from '../request.service';
import { RequestListService } from './request-list.service';
import { MaterialModule } from '../../material/material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RequestListComponent } from '../request-list/request-list.component';




@NgModule({
  declarations: [RequestComponent, RequestListComponent
 ],
  imports: [
    CommonModule,
    RequestRoutingModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    MatToolbarModule,
    BrowserAnimationsModule,
    MatCheckboxModule
  ],
  providers: [RequestService, RequestListService, ]
})
export class RequestModule { }

import { Component, OnInit } from '@angular/core';
import { RequestListService } from './request-list.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Ticket, RequestView } from 'src/app/service/data/classes/all-ticket';


@Component({
  selector: 'app-request-list',
  templateUrl: './request-list.component.html',
  styleUrls: ['./request-list.component.scss']
})
export class RequestListComponent implements OnInit {

  deleteMessage: string;
  tickets: Ticket[];
  requestView: RequestView[];

  constructor(private listRequestService: RequestListService,
              private router: Router,
              private allTicket: RequestListService) {}

  ngOnInit() {
    this.listRequests();
    this.listRequestView();
    console.log('Ticket: ' + this.tickets);
  }

  cancelButton = function() {
    this.router.navigateByUrl('/welcome');
  };

  listRequests() {
    this.allTicket.getAllTickets().subscribe(
      data => {
        console.log('Data: ', data);
        this.tickets = data;
      },
      error => console.log('in error ', error),
      () => console.log('Observable listRequest is now complete.')
    );
  }

  listRequestView() {
    this.allTicket.getRequestView().subscribe(
      data => {
        console.log('Data: ', data);
        this.requestView = data;
      },
      error => console.log('in error ', error),
      () => console.log('Observable listRequestView is now complete.')
    );
  }
}


import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RequestComponent } from './request.component';
import { CommonModule } from '@angular/common';
import { RouteGuardService } from '../service/route-guard.service';
import { UnassignedRequestService } from './unassigned-request/unassigned-request.service';

const routes: Routes = [
  {
    path: 'request',
    component: RequestComponent, canActivate: [RouteGuardService]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
 export class RequestRoutingModule { }

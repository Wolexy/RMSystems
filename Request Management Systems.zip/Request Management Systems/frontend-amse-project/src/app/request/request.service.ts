import { Injectable } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatToolbarModule } from '@angular/material/toolbar';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Ticket, Priority, User, Job,
  Department, Site, Category, SubCategory, Technician
} from 'src/app/service/data/classes/all-ticket';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class RequestService {
// Define url and REST APIs for backend
  private baseUrl = 'http://localhost:8080/api/';
  priorityObject: Observable<Priority[]>;
  userObject: Observable<User[]>;
  jobObject: Observable<Job[]>;
  departmentObject: Observable<Department[]>;
  siteObject: Observable<Site[]>;
  categoryObject: Observable<Category[]>;
  subCategoryObject: Observable<SubCategory[]>;

  constructor(private http: HttpClient) { } // httpclient defined in the constructor

  form: FormGroup = new FormGroup({
    $key: new FormControl(null),
    requestTitle: new FormControl('', Validators.required),
    requestDescription: new FormControl(''),
    requestDate: new FormControl(new Date()),
    department: new FormControl('', Validators.required),
    user: new FormControl('', Validators.required),
    job: new FormControl(''),
    priority: new FormControl('', Validators.required),
    category: new FormControl('', Validators.required),
    subCategory: new FormControl('', Validators.required),
    site: new FormControl('', Validators.required),
    status: new FormControl('STS01'),
    technician: new FormControl(''),
    approval: new FormControl('Under Review'),
    requestApprover: new FormControl(''),
    knownIssue: new FormControl(''),
    relatedCase: new FormControl(''),
    contactNumber: new FormControl(''),
    emailToNotify: new FormControl(''),
    issueDate: new FormControl('')
  });

  // Define getMethods for each object

  getPriorities(): Observable<Priority[]> {
    this.priorityObject = this.http.get<Priority[]>(this.baseUrl + 'priorities');
    console.log(this.priorityObject);
    return this.priorityObject;
  }

  getUsers(): Observable<User[]> {
    this.userObject = this.http.get<User[]>(this.baseUrl + 'users');
    console.log(this.userObject);
    return this.userObject;
  }

  getJobs(): Observable<Job[]> {
    this.jobObject = this.http.get<Job[]>(this.baseUrl + 'jobs');
    console.log(this.jobObject);
    return this.jobObject;
  }

  getDepartments(): Observable<Department[]> {
    this.departmentObject = this.http.get<Department[]>(this.baseUrl + 'departments');
    console.log(this.departmentObject);
    return this.departmentObject;
  }
  getSites(): Observable<Site[]> {
    this.siteObject = this.http.get<Site[]>(this.baseUrl + 'sites');
    console.log(this.siteObject);
    return this.siteObject;
  }
  getCategories(): Observable<Category[]> {
    this.categoryObject = this.http.get<Category[]>(this.baseUrl + 'categories');
    console.log(this.categoryObject);
    return this.categoryObject;
  }
  getSubCategories(): Observable<SubCategory[]> {
    this.subCategoryObject = this.http.get<SubCategory[]>(this.baseUrl + 'subCategories');
    console.log(this.subCategoryObject);
    return this.subCategoryObject;
  }
  // This method create new ticket - works with formGroup created above and in RequestService

  createTicket(ticket: Ticket): Observable<any> {
    const headers = { 'content-type': 'application/json' };
    const body = JSON.stringify(ticket);
    console.log(body);
    return this.http.post(`${this.baseUrl}new_tickets`, ticket, {headers});
  }

}

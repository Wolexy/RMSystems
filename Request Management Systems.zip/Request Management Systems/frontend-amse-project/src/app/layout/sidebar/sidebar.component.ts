import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
  isHidden1 = true;
  isHidden2 = true;

  // Define variables for sidebar
   dropdown = document.getElementsByClassName('dropdown-btn');
   i: any;
  constructor() { }

  ngOnInit(): void {
    for (this.i = 0; this.i < this.dropdown.length; this.i++) {
      this.dropdown[this.i].addEventListener('click', function() {
      this.classList.toggle('active');
      const dropdownContent = this.nextElementSibling;
      if (dropdownContent.style.display === 'block') {
      dropdownContent.style.display = 'none';
      } else {
      dropdownContent.style.display = 'block';
      }
      });
    } 
  }

  toggleDisplay1() {
    this.isHidden1 = !this.isHidden1;
  }
    toggleDisplay2() {
    this.isHidden2 = !this.isHidden2;
  }
}

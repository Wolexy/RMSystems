import { Component, OnInit, ViewChild } from '@angular/core';
import { MaterialModule } from '../../material/material.module';
import { HardcodedAuthService } from 'src/app/service/hardcoded-auth.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  // tslint:disable-next-line:no-inferrable-types
  // isUserLoggedIn: boolean = false;
  log: any;
  constructor(public hardcodedAuthService: HardcodedAuthService) { }

  ngOnInit(): void {
  //  this.isUserLoggedIn = this.hardcodedAuthService.isUserLoggedIn();
    this.hardcodedAuthService.logout();
    
  }

}

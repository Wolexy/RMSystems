This application is written to showcase MVC design pattern with:

i. MySql as database
ii. Java with Spring framework (Spring boot) backend
iii. Angular application for the frontend

Steps to run the application:

This application was built on Windows operating systems, but it should also run on any OS platform.  It is assumed the system it will run meets the prerequisites:

i. Java JDK 8 or above
ii. MySql 8 is installed
iii. Node.js version 12.8.0 or above
iv. Angular CLI: 9.0.6
v. Any IDE that supports JAva/Spring is OK but I used IntelliJ Idea and STS. Any of the two is OK.
vi. I used Visual Studio Code (VS Code) for the frontend.

Download and unzip the file to a root location.

Part A -  Database
1. with adequate user access, run the db_script.sql included in other to create the database and its tables from Mysql IDE. I also provide some sample data.

Part B -  Backend
1. Load the backend-amse-project folder from Spring Tool Suite IDE or IntelliJ Idea.
2. in STS, RMB (Right Mouse Button) on the project folder and Click Maven > Update project. Wait for the dependencies to be downloaded/updated
3. RMB on the project folder and click Run As > Spring Boot App. or Java Application. The server will start running on port 8080.

Part B - Frontend
1. Open the VSCode IDE
2. Open Folder and navigate to the frontend folder (frontend-amse-project) from Visual Studio Code (VSCode)
3. From the menu bar, Open Terminal > New Terminal
4. type "npm install" (without quotes). Wait for dependencies to be downloaded and installed
4. type "ng serve -o" (without quotes). A login page will open in explorer
5. Login with "amse" and "amse" as username and password respectively , without quote.

Please note that this application is not without error. Therefore use it at your own risk.

Enjoy.
kolaajala@hotmail.com
